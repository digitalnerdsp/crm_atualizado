import { dirname } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { serve } from "@hono/node-server";
import { createNodeWebSocket } from "@hono/node-ws";
import type { Session, User } from "better-auth/types";
import { eq, sql } from "drizzle-orm";
import { migrate } from "drizzle-orm/node-postgres/migrator";
import { Hono } from "hono";
import { cors } from "hono/cors";
import { HTTPException } from "hono/http-exception";
import {
  describeRoute,
  openAPIRouteHandler,
  resolver,
  validator,
} from "hono-openapi";
import * as v from "valibot";
import activity from "./activity";
import admin from "./admin";
import { auth } from "./auth";
import { getPublicBranding } from "./branding";
import calendar from "./calendar";
import column from "./column";
import comment from "./comment";
import config from "./config";
import crm from "./crm";
import { initializeCrmSubscriptions } from "./crm/subscribe-events";
import dashboard from "./dashboard";
import db, { getDatabase, schema } from "./database";
import { backfillWorkspaceRoles } from "./database/backfill-workspace-roles";
import { prepareDatabaseStartup } from "./database/prepare-database-startup";
import { waitForDatabase } from "./database/wait-for-database";
import { eventContext } from "./events";
import externalLink from "./external-link";
import finance from "./finance";
import genericWebhookIntegration from "./generic-webhook-integration";
import githubIntegration, {
  handleGithubWebhookRoute,
} from "./github-integration";
import getInstanceStatus from "./instance/controllers/get-instance-status";
import invitation from "./invitation";
import label from "./label";
import mcpRoutes, { mcpWellKnownRoutes } from "./mcp";
import notification from "./notification";
import notificationPreferences from "./notification-preferences";
import oauth from "./oauth";
import { initializePlugins } from "./plugins";
import profile from "./profile";
import project from "./project";
import { getPublicProject } from "./project/controllers/get-public-project";
import { initializeScheduler, shutdownScheduler } from "./scheduler";
import search from "./search";
import setup from "./setup";
import {
  assertStorageConfigured,
  getPrivateObject,
  uploadLocalObjectFromSignedRequest,
} from "./storage/s3";
import task from "./task";
import taskRelation from "./task-relation";
import taskTemplate from "./task-template";
import telegramIntegration from "./telegram-integration";
import timeEntry from "./time-entry";
import {
  authenticateApiRequest,
  resolveAssetBearerOrCookie,
} from "./utils/authenticate-api-request";
import { getInvitationDetails } from "./utils/check-registration-allowed";
import { isInstanceAdmin } from "./utils/is-instance-admin";
import {
  dedupeOperationIds,
  ensureOperationSummaries,
  markOptionalSchemaFieldsNullable,
  mergeOpenApiSpecs,
  normalizeApiServerUrl,
  normalizeEmptyAndEnumSchemas,
  normalizeEmptyRequiredArrays,
  normalizeMalformedPropertySchemas,
  normalizeNullableSchemasForOpenApi30,
  normalizeOrganizationAuthOperations,
} from "./utils/openapi-spec";
import { validateWorkspaceAccess } from "./utils/validate-workspace-access";
import workflowRule from "./workflow-rule";
import workspace from "./workspace";
import {
  addConnection,
  addUserConnection,
  crmPipelineRoom,
  initializeWebSocketAdapter,
  removeConnection,
  removeUserConnection,
  shutdownWebSocketAdapter,
} from "./ws";

type ApiKey = {
  id: string;
  userId: string;
  enabled: boolean;
  permissions: Record<string, string[]> | null;
};

type AppVariables = {
  Variables: {
    user: User | null;
    session: Session | null;
    userId: string;
    apiKey?: ApiKey;
  };
};

type ApiVariables = {
  Variables: {
    user: User | null;
    session: Session | null;
    userId: string;
    userEmail: string;
    apiKey?: ApiKey;
  };
};

const SAFE_INLINE_ASSET_TYPES = new Set([
  "image/apng",
  "image/avif",
  "image/gif",
  "image/heic",
  "image/heif",
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
]);

function buildContentDisposition(filename: string, inline: boolean) {
  const normalized = filename
    .normalize("NFC")
    .replace(/[\r\n"]/g, "")
    .trim();
  const safeFilename = normalized || "file";
  const asciiFallback =
    safeFilename
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[\\/]/g, "-")
      .replace(/[^\x20-\x7e]+/g, "_")
      .replace(/\s+/g, " ")
      .trim() || "file";
  const encodedFilename = encodeURIComponent(safeFilename).replace(
    /['()*]/g,
    (char) => `%${char.charCodeAt(0).toString(16).toUpperCase()}`,
  );

  const disposition = inline ? "inline" : "attachment";
  return `${disposition}; filename="${asciiFallback}"; filename*=UTF-8''${encodedFilename}`;
}

export function createApp() {
  const app = new Hono<AppVariables>();
  const branding = getPublicBranding();
  const nodeWs = createNodeWebSocket({ app });
  const { upgradeWebSocket, injectWebSocket } = nodeWs;
  const corsOriginSource = [
    process.env.CORS_ORIGINS,
    process.env.KANEO_CLIENT_URL,
  ].find((value) => value?.trim());
  const corsOrigins = corsOriginSource
    ?.split(",")
    .map((origin) => origin.trim())
    .filter(Boolean);

  app.use(
    "*",
    cors({
      credentials: true,
      origin: (origin) => {
        if (!corsOrigins) {
          return origin || "*";
        }

        if (!origin) {
          return null;
        }

        return corsOrigins.includes(origin) ? origin : null;
      },
    }),
  );

  const api = new Hono<ApiVariables>();

  api.get("/health", (c) => {
    return c.json({ status: "ok" });
  });

  api.get(
    "/instance/status",
    describeRoute({
      operationId: "getInstanceStatus",
      tags: ["Instance"],
      description:
        "Public instance setup status. When hasUsers is false the setup endpoint can initialize the instance.",
      security: [],
      responses: {
        200: {
          description: "Instance status",
          content: {
            "application/json": {
              schema: resolver(
                v.object({
                  hasUsers: v.boolean(),
                  hasAdmin: v.boolean(),
                }),
              ),
            },
          },
        },
      },
    }),
    async (c) => {
      const status = await getInstanceStatus();
      return c.json(status);
    },
  );

  const publicProjectApi = api.get("/public-project/:id", async (c) => {
    const { id } = c.req.param();
    const project = await getPublicProject(id);

    return c.json(project);
  });

  api.post("/github-integration/webhook", handleGithubWebhookRoute);

  const invitationPublicApi = api.get("/invitation/public/:id", async (c) => {
    const { id } = c.req.param();
    const result = await getInvitationDetails(id);
    return c.json(result);
  });

  api.get(
    "/auth/get-session",
    describeRoute({
      operationId: "getSession",
      tags: ["Authentication"],
      description: "Get the current authenticated session",
      security: [],
      responses: {
        200: {
          description: "Current session details or null when unauthenticated",
          content: {
            "application/json": { schema: resolver(v.any()) },
          },
        },
      },
    }),
    async (c) => {
      const session = await auth.api.getSession({ headers: c.req.raw.headers });
      return c.json(session ?? null);
    },
  );

  api.get(
    "/asset/:id",
    describeRoute({
      operationId: "getAsset",
      tags: ["Assets"],
      description: "Download an uploaded asset by ID",
      security: [],
      responses: {
        200: {
          description: "The requested asset binary stream",
          content: {
            "*/*": { schema: { type: "string", format: "binary" } },
          },
        },
      },
    }),
    validator("param", v.object({ id: v.string() })),
    async (c) => {
      const { id } = c.req.param();
      const [asset] = await db
        .select({
          id: schema.assetTable.id,
          objectKey: schema.assetTable.objectKey,
          mimeType: schema.assetTable.mimeType,
          filename: schema.assetTable.filename,
          workspaceId: schema.assetTable.workspaceId,
          isPublic: schema.projectTable.isPublic,
        })
        .from(schema.assetTable)
        .innerJoin(
          schema.projectTable,
          eq(schema.assetTable.projectId, schema.projectTable.id),
        )
        .where(eq(schema.assetTable.id, id))
        .limit(1);

      if (!asset) {
        throw new HTTPException(404, { message: "Asset not found" });
      }

      const { userId, apiKeyId } = await resolveAssetBearerOrCookie(c);

      if (userId) {
        await validateWorkspaceAccess(userId, asset.workspaceId, apiKeyId);
      } else if (!asset.isPublic) {
        throw new HTTPException(401, { message: "Unauthorized" });
      }

      try {
        const object = await getPrivateObject(asset.objectKey);
        const storedContentType =
          (object.contentType || asset.mimeType)
            .toLowerCase()
            .split(";")[0]
            ?.trim() ?? "";
        const inline = SAFE_INLINE_ASSET_TYPES.has(storedContentType);

        return new Response(object.body as BodyInit, {
          headers: {
            "Cache-Control": asset.isPublic
              ? "public, max-age=300"
              : "private, max-age=120",
            "Content-Disposition": buildContentDisposition(
              asset.filename,
              inline,
            ),
            "Content-Length": object.contentLength?.toString() || "",
            "Content-Type": inline
              ? storedContentType
              : "application/octet-stream",
            "X-Content-Type-Options": "nosniff",
            ETag: object.etag || "",
            "Last-Modified": object.lastModified?.toUTCString() || "",
          },
        });
      } catch (error) {
        console.error("Failed to stream asset:", error);
        throw new HTTPException(404, { message: "Asset object not found" });
      }
    },
  );

  api.put(
    "/storage/local-upload",
    describeRoute({
      operationId: "uploadLocalAssetObject",
      tags: ["Assets"],
      description:
        "Upload an asset binary using a short-lived signed local storage URL",
      security: [],
      responses: {
        204: {
          description: "Asset uploaded successfully",
        },
      },
    }),
    async (c) => {
      try {
        await uploadLocalObjectFromSignedRequest(c.req.raw);
        return c.body(null, 204);
      } catch (error) {
        throw new HTTPException(400, {
          message:
            error instanceof Error ? error.message : "Invalid local upload.",
        });
      }
    },
  );

  const configApi = api.route("/config", config);
  api.route("/setup", setup);

  const honoOpenApiHandler = openAPIRouteHandler(api, {
    documentation: {
      openapi: "3.0.3",
      info: {
        title: `${branding.appName} API`,
        version: "1.0.0",
        description: `${branding.appName} management API - Manage projects, tasks, labels, and more`,
      },
      servers: [
        {
          url: normalizeApiServerUrl(
            process.env.KANEO_API_URL || "http://localhost:1337",
          ),
          description: `${branding.appName} API Server`,
        },
      ],
      components: {
        securitySchemes: {
          bearerAuth: {
            type: "http",
            scheme: "bearer",
            description: "API key or session token (Bearer)",
          },
        },
      },
      security: [{ bearerAuth: [] }],
    },
  });

  api.get("/admin/openapi", async (c) => {
    await authenticateApiRequest(c);
    if (!c.get("session") || !(await isInstanceAdmin(c))) {
      throw new HTTPException(403, { message: "Forbidden" });
    }

    const maybeResponse = await honoOpenApiHandler(c, async () => {});
    const honoSpecResponse = maybeResponse ?? c.res;
    const honoSpec = (await honoSpecResponse.json()) as Record<string, unknown>;

    let authSpec: Record<string, unknown> = {};
    try {
      authSpec = (await auth.api.generateOpenAPISchema()) as Record<
        string,
        unknown
      >;
    } catch (error) {
      console.error("Failed to generate Better Auth OpenAPI schema:", error);
    }

    const normalizedAuthSpec = normalizeOrganizationAuthOperations(authSpec);
    c.header("Cache-Control", "private, no-store");
    return c.json(
      ensureOperationSummaries(
        dedupeOperationIds(
          markOptionalSchemaFieldsNullable(
            normalizeNullableSchemasForOpenApi30(
              normalizeEmptyAndEnumSchemas(
                normalizeEmptyRequiredArrays(
                  normalizeMalformedPropertySchemas(
                    mergeOpenApiSpecs(honoSpec, normalizedAuthSpec),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  });

  // Better Auth serves GET /auth/device as JSON. Browsers that open the API URL
  // directly expect a page — redirect full document navigations to the web app.
  const authDeviceQuerySchema = v.object({
    user_code: v.optional(v.string()),
    ui: v.optional(v.picklist(["1"])),
  });

  api.get(
    "/auth/device",
    describeRoute({
      operationId: "getDeviceAuthorizationPage",
      tags: ["Authentication"],
      description:
        "Redirect browser-based device authorization requests to the web UI",
      security: [],
      parameters: [
        {
          name: "user_code",
          in: "query",
          required: false,
          schema: {
            type: "string",
          },
          description: "The device authorization user code.",
        },
        {
          name: "ui",
          in: "query",
          required: false,
          schema: {
            type: "string",
            enum: ["1"],
          },
          description: "Force a redirect to the web UI.",
        },
      ],
      responses: {
        302: {
          description: "Redirects the browser to the web app device screen",
        },
        200: {
          description: "Device authorization payload from Better Auth",
          content: {
            "application/json": { schema: resolver(v.any()) },
          },
        },
      },
    }),
    validator("query", authDeviceQuerySchema),
    async (c) => {
      const { user_code: userCode, ui } = c.req.valid("query");
      const secFetchDest = c.req.header("Sec-Fetch-Dest");
      const forceUiRedirect = ui === "1";
      // Top-level browser tab / address bar (not `fetch()` / XHR from the SPA).
      // Optional `ui=1` forces redirect when Sec-Fetch-* headers are missing (e.g. some clients).
      if (forceUiRedirect || secFetchDest === "document") {
        const clientUrl = (
          process.env.KANEO_CLIENT_URL || "http://localhost:5173"
        ).replace(/\/$/, "");
        const deviceUrl = new URL(`${clientUrl}/device`);
        if (userCode) {
          deviceUrl.searchParams.set("user_code", userCode);
        }
        return c.redirect(deviceUrl.toString(), 302);
      }
      return auth.handler(c.req.raw);
    },
  );

  api.on(["POST", "GET", "PUT", "DELETE"], "/auth/*", async (c) => {
    const authHeader = c.req.header("Authorization");
    const apiKeyHeader = c.req.header("x-api-key");
    const bearerMatch = authHeader?.match(/^Bearer\s+(\S+)$/i);

    if (bearerMatch && !apiKeyHeader) {
      const session = await auth.api.getSession({
        headers: c.req.raw.headers,
      });

      // Preserve Better Auth bearer session tokens on auth routes.
      if (session?.session && session.user) {
        return auth.handler(c.req.raw);
      }

      const headers = new Headers(c.req.raw.headers);

      // Better Auth API key plugin validates from x-api-key by default.
      headers.set("x-api-key", bearerMatch[1]);

      return auth.handler(
        new Request(c.req.raw, {
          headers,
        }),
      );
    }

    return auth.handler(c.req.raw);
  });

  api.route("/", mcpRoutes);

  api.use("*", async (c, next) => {
    const path = c.req.path;
    if (path.startsWith("/api/mcp") || path.startsWith("/api/.well-known/")) {
      return next();
    }
    try {
      await authenticateApiRequest(c);
    } catch (error) {
      if (error instanceof HTTPException) {
        throw error;
      }
      console.error("API authentication failed:", error);
      throw new HTTPException(500, { message: "Internal Server Error" });
    }

    const windowId = c.req.header("X-Nortys-Window-Id");
    const userId = c.get("userId");
    const initiatorId = windowId ? `${userId}:${windowId}` : userId;

    return eventContext.run({ initiatorId }, next);
  });

  const oauthApi = api.route("/oauth", oauth);

  const financeApi = api.route("/finance", finance);
  const crmApi = api.route("/crm", crm);
  const projectApi = api.route("/project", project);
  const profileApi = api.route("/profile", profile);
  const taskApi = api.route("/task", task);
  const columnApi = api.route("/column", column);
  const activityApi = api.route("/activity", activity);
  const calendarApi = api.route("/calendar", calendar);
  const dashboardApi = api.route("/dashboard", dashboard);
  const commentApi = api.route("/comment", comment);
  const timeEntryApi = api.route("/time-entry", timeEntry);
  const labelApi = api.route("/label", label);
  const notificationApi = api.route("/notification", notification);
  const notificationPreferencesApi = api.route(
    "/notification-preferences",
    notificationPreferences,
  );
  const searchApi = api.route("/search", search);
  const githubIntegrationApi = api.route(
    "/github-integration",
    githubIntegration,
  );
  const genericWebhookIntegrationApi = api.route(
    "/generic-webhook-integration",
    genericWebhookIntegration,
  );
  const telegramIntegrationApi = api.route(
    "/telegram-integration",
    telegramIntegration,
  );
  const taskRelationApi = api.route("/task-relation", taskRelation);
  const taskTemplateApi = api.route("/task-template", taskTemplate);
  const externalLinkApi = api.route("/external-link", externalLink);
  const workflowRuleApi = api.route("/workflow-rule", workflowRule);
  const invitationApi = api.route("/invitation", invitation);
  const workspaceApi = api.route("/workspace", workspace);
  const adminApi = api.route("/admin", admin);

  app.route(
    "/",
    mcpWellKnownRoutes(
      (process.env.KANEO_API_URL || "http://localhost:1337").replace(
        /\/api\/?$/,
        "",
      ),
    ),
  );

  // User-scoped WebSocket endpoint — MUST be registered before /ws/:projectId
  // so the literal path "user" isn't consumed by the param route.
  api.get(
    "/ws/user",
    upgradeWebSocket(async (c) => {
      try {
        await authenticateApiRequest(c);
      } catch (error) {
        if (error instanceof HTTPException) {
          throw error;
        }
        console.error("API authentication failed:", error);
        throw new HTTPException(500, { message: "Internal Server Error" });
      }

      const userId = c.get("userId");
      let conn: ReturnType<typeof addUserConnection> | null = null;

      return {
        onOpen(_evt, ws) {
          if (userId) {
            conn = addUserConnection(userId, ws);
          }
        },
        onMessage(evt) {
          try {
            const raw =
              typeof evt.data === "string"
                ? evt.data
                : Buffer.isBuffer(evt.data)
                  ? evt.data.toString()
                  : null;
            if (raw) {
              const msg = JSON.parse(raw) as { type?: string };
              if (msg?.type === "ping") {
                // keepalive — no-op
              }
            }
          } catch {
            // Ignore malformed messages
          }
        },
        onClose() {
          if (conn && userId) {
            removeUserConnection(userId, conn);
          }
        },
      };
    }),
  );

  api.get(
    "/ws/crm/:pipelineId",
    upgradeWebSocket(async (c) => {
      const pipelineId = c.req.param("pipelineId");

      if (!pipelineId) {
        throw new HTTPException(400, { message: "Pipeline ID is required" });
      }

      try {
        await authenticateApiRequest(c);
      } catch (error) {
        if (error instanceof HTTPException) {
          throw error;
        }
        console.error("API authentication failed:", error);
        throw new HTTPException(500, { message: "Internal Server Error" });
      }

      const userId = c.get("userId");

      const [pipeline] = await db
        .select({ workspaceId: schema.crmPipelineTable.workspaceId })
        .from(schema.crmPipelineTable)
        .where(eq(schema.crmPipelineTable.id, pipelineId))
        .limit(1);

      if (!pipeline) {
        throw new HTTPException(401, { message: "Unauthorized" });
      }

      await validateWorkspaceAccess(userId, pipeline.workspaceId);

      const windowId = c.req.query("windowId");
      const initiatorId = windowId ? `${userId}:${windowId}` : userId;
      const room = crmPipelineRoom(pipelineId);
      let conn: ReturnType<typeof addConnection> | null = null;

      return {
        onOpen(_evt, ws) {
          conn = addConnection(room, ws, userId, initiatorId);
        },
        onMessage() {
          // Client keepalive pings; receiving them is enough.
        },
        onClose() {
          if (conn) removeConnection(room, conn);
        },
      };
    }),
  );

  app.get(
    "/ws/:projectId",
    upgradeWebSocket(async (c) => {
      const projectId = c.req.param("projectId");

      try {
        await authenticateApiRequest(c);
      } catch (error) {
        if (error instanceof HTTPException) {
          throw error;
        }
        console.error("API authentication failed:", error);
        throw new HTTPException(500, { message: "Internal Server Error" });
      }

      const userId = c.get("userId");

      if (projectId) {
        const [project] = await db
          .select({ workspaceId: schema.projectTable.workspaceId })
          .from(schema.projectTable)
          .where(eq(schema.projectTable.id, projectId))
          .limit(1);

        if (!project) {
          throw new HTTPException(401, { message: "Unauthorized" });
        }

        await validateWorkspaceAccess(userId, project.workspaceId);
      }

      const windowId = c.req.query("windowId");
      const initiatorId = windowId ? `${userId}:${windowId}` : userId;
      let conn: ReturnType<typeof addConnection> | null = null;

      return {
        onOpen(_evt, ws) {
          if (projectId) {
            conn = addConnection(projectId, ws, userId, initiatorId);
          }
        },
        onMessage(evt) {
          // Respond to client keepalive pings (sent every 30s to prevent
          // Cloudflare from closing idle connections at 100s timeout)
          try {
            const raw =
              typeof evt.data === "string"
                ? evt.data
                : Buffer.isBuffer(evt.data)
                  ? evt.data.toString()
                  : null;
            if (raw) {
              const msg = JSON.parse(raw) as { type?: string };
              if (msg?.type === "ping") {
                // No-op: receiving the ping is enough to satisfy Cloudflare.
                // A pong response is optional but helps confirm liveness.
              }
            }
          } catch {
            // Ignore malformed messages
          }
        },
        onClose() {
          if (conn && projectId) {
            removeConnection(projectId, conn);
          }
        },
      };
    }),
  );

  app.route("/api", api);

  return {
    app,
    api,
    injectWebSocket,
    activityApi,
    calendarApi,
    dashboardApi,
    columnApi,
    commentApi,
    configApi,
    externalLinkApi,
    genericWebhookIntegrationApi,
    githubIntegrationApi,
    invitationApi,
    invitationPublicApi,
    labelApi,
    notificationApi,
    notificationPreferencesApi,
    profileApi,
    projectApi,
    publicProjectApi,
    searchApi,
    taskApi,
    taskRelationApi,
    taskTemplateApi,
    telegramIntegrationApi,
    timeEntryApi,
    workflowRuleApi,
    workspaceApi,
    oauthApi,
    adminApi,
    crmApi,
    financeApi,
  };
}

export async function runStartupTasks() {
  const currentDir = dirname(fileURLToPath(import.meta.url));

  assertStorageConfigured();

  await prepareDatabaseStartup({
    waitForDatabase: async () => {
      await waitForDatabase({
        query: async () => {
          await getDatabase().execute(sql`SELECT 1`);
        },
      });
    },
    runStartupMigrations: async () => {
      console.log("🔄 Migrating database...");
      await migrate(getDatabase(), {
        migrationsFolder: `${currentDir}/../drizzle`,
      });
      console.log("✅ Database migrated successfully!");
    },
  });

  // Reaches workspaces created before a role or permission resource existed.
  // Runs after migrations because it reads and writes tables they create.
  await backfillWorkspaceRoles();

  initializePlugins();
  initializeCrmSubscriptions();
  initializeScheduler();
  await initializeWebSocketAdapter();
}

export async function startServer(
  injectWebSocket: ReturnType<typeof createNodeWebSocket>["injectWebSocket"],
  port = 1337,
) {
  try {
    await runStartupTasks();
  } catch (error) {
    console.error("❌ Database migration failed!", error);
    process.exit(1);
  }

  let shuttingDown = false;

  const server = serve(
    {
      fetch: app.fetch,
      port,
    },
    () => {
      console.log(
        `⚡ API is running at ${process.env.KANEO_API_URL || "http://localhost:1337"}`,
      );
    },
  );

  injectWebSocket(server);

  const gracefulShutdown = async () => {
    if (shuttingDown) return;
    shuttingDown = true;

    console.log("🛑 Shutting down gracefully...");
    shutdownScheduler();
    await shutdownWebSocketAdapter();
    server.close();
    process.exit(0);
  };

  process.on("SIGTERM", () => {
    void gracefulShutdown();
  });

  process.on("SIGINT", () => {
    void gracefulShutdown();
  });
}

const createdApp = createApp();
const {
  app,
  injectWebSocket,
  activityApi,
  calendarApi,
  dashboardApi,
  columnApi,
  commentApi,
  configApi,
  externalLinkApi,
  genericWebhookIntegrationApi,
  githubIntegrationApi,
  invitationApi,
  invitationPublicApi,
  labelApi,
  notificationApi,
  notificationPreferencesApi,
  profileApi,
  projectApi,
  publicProjectApi,
  searchApi,
  taskApi,
  taskRelationApi,
  taskTemplateApi,
  telegramIntegrationApi,
  timeEntryApi,
  workflowRuleApi,
  workspaceApi,
  oauthApi,
  adminApi,
  crmApi,
  financeApi,
} = createdApp;

const isMainModule =
  Boolean(process.argv[1]) &&
  import.meta.url === pathToFileURL(process.argv[1]).href;

if (isMainModule) {
  void startServer(injectWebSocket);
}

export type AppType =
  | typeof configApi
  | typeof projectApi
  | typeof taskApi
  | typeof columnApi
  | typeof activityApi
  | typeof calendarApi
  | typeof dashboardApi
  | typeof commentApi
  | typeof timeEntryApi
  | typeof labelApi
  | typeof notificationApi
  | typeof notificationPreferencesApi
  | typeof profileApi
  | typeof searchApi
  | typeof githubIntegrationApi
  | typeof genericWebhookIntegrationApi
  | typeof telegramIntegrationApi
  | typeof taskRelationApi
  | typeof taskTemplateApi
  | typeof externalLinkApi
  | typeof workflowRuleApi
  | typeof invitationApi
  | typeof workspaceApi
  | typeof publicProjectApi
  | typeof invitationPublicApi
  | typeof oauthApi
  | typeof adminApi
  | typeof crmApi
  | typeof financeApi;

export default app;
