import { standardSchemaResolver } from "@hookform/resolvers/standard-schema";
import { useRouter } from "@tanstack/react-router";
import { Eye, EyeOff } from "lucide-react";
import { useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { z } from "zod/v4";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { authClient } from "@/lib/auth-client";
import { toast } from "@/lib/toast";

export type SignUpFormValues = {
  email: string;
  password: string;
  name: string;
};

type SignUpFormProps = {
  invitationId?: string;
  defaultEmail?: string;
  /**
   * Captcha token lifted from the page level. When the page renders Turnstile
   * (cloud only), it passes the verified token here. `null` means captcha is
   * required but not yet completed — the submit button stays disabled.
   * `undefined` means captcha isn't required at all (self-hosted).
   */
  turnstileToken?: string | null;
};

export function SignUpForm({
  invitationId,
  defaultEmail,
  turnstileToken,
}: SignUpFormProps) {
  const { t } = useTranslation();
  const [showPassword, setShowPassword] = useState(false);
  const [isPending, setIsPending] = useState(false);
  const { history } = useRouter();
  const captchaRequired = turnstileToken !== undefined;

  const signUpSchema = useMemo(
    () =>
      z.object({
        email: z.email(),
        password: z.string().min(8, {
          message: t("auth:signUpForm.passwordTooShort"),
        }),
        name: z.string(),
      }),
    [t],
  );

  const form = useForm<SignUpFormValues>({
    resolver: standardSchemaResolver(signUpSchema),
    defaultValues: {
      email: defaultEmail || "",
      password: "",
      name: "",
    },
  });

  const onSubmit = async (data: SignUpFormValues) => {
    setIsPending(true);
    try {
      const headers: Record<string, string> = {};
      if (turnstileToken) {
        headers["x-turnstile-token"] = turnstileToken;
      }
      if (invitationId) {
        headers["x-invitation-id"] = invitationId;
      }

      const result = await authClient.signUp.email(
        {
          email: data.email,
          name: data.name,
          password: data.password,
        },
        Object.keys(headers).length > 0 ? { headers } : undefined,
      );

      if (result.error) {
        toast.error(result.error.message || t("auth:signUpForm.failedSignUp"));
        return;
      }

      toast.success(t("auth:signUpForm.accountCreated"));

      if (invitationId) {
        history.push(`/invitation/accept/${invitationId}`);
      } else {
        history.push("/dashboard");
      }
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : t("auth:signUpForm.failedSignUp"),
      );
    } finally {
      setIsPending(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
        <div className="space-y-3">
          <FormField
            control={form.control}
            name="name"
            render={({ field, fieldState }) => (
              <FormItem>
                <FormLabel className="text-sm font-medium">
                  {t("auth:signUpForm.fullName")}
                </FormLabel>
                <FormControl>
                  <Input
                    placeholder={t("auth:signUpForm.namePlaceholder")}
                    type="text"
                    autoComplete="name"
                    {...field}
                  />
                </FormControl>
                <FormMessage>{fieldState.error?.message}</FormMessage>
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="email"
            render={({ field, fieldState }) => (
              <FormItem>
                <FormLabel className="text-sm font-medium">
                  {t("auth:forms.email")}
                </FormLabel>
                <FormControl>
                  <Input
                    placeholder={t("auth:forms.emailPlaceholder")}
                    type="email"
                    autoComplete="email"
                    disabled={!!defaultEmail}
                    {...field}
                  />
                </FormControl>
                <FormMessage>{fieldState.error?.message}</FormMessage>
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="password"
            render={({ field, fieldState }) => (
              <FormItem>
                <FormLabel className="text-sm font-medium">
                  {t("auth:forms.password")}
                </FormLabel>
                <FormControl>
                  <div className="relative">
                    <Input
                      placeholder={t("auth:forms.passwordPlaceholder")}
                      type={showPassword ? "text" : "password"}
                      autoComplete="new-password"
                      {...field}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      aria-label={
                        showPassword
                          ? t("auth:forms.hidePassword")
                          : t("auth:forms.showPassword")
                      }
                      aria-pressed={showPassword}
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </FormControl>
                <FormMessage>{fieldState.error?.message}</FormMessage>
              </FormItem>
            )}
          />
        </div>

        <Button
          type="submit"
          disabled={isPending || (captchaRequired && !turnstileToken)}
          className="w-full mt-4"
        >
          {isPending
            ? t("auth:signUpForm.creatingAccount")
            : t("auth:signUpForm.createAccount")}
        </Button>
      </form>
    </Form>
  );
}
