## [2.9.8](https://github.com/usekaneo/kaneo/compare/v2.9.7...v2.9.8) (2026-07-19)


### Features

* webhook events, unicode slugs, board sort ([#1408](https://github.com/usekaneo/kaneo/issues/1408)) ([c17187e](https://github.com/usekaneo/kaneo/commit/c17187ece24b3a3da04eb27192fde2f4f68375d5)), closes [#1395](https://github.com/usekaneo/kaneo/issues/1395) [#1357](https://github.com/usekaneo/kaneo/issues/1357) [#1396](https://github.com/usekaneo/kaneo/issues/1396)
## [2.9.7](https://github.com/usekaneo/kaneo/compare/v2.9.6...v2.9.7) (2026-07-18)


### Features

* **web:** motion and fluidity polish pass ([#1407](https://github.com/usekaneo/kaneo/issues/1407)) ([63e44cc](https://github.com/usekaneo/kaneo/commit/63e44ccff707e1add078bfe9976980f6fc362658))
## [2.9.6](https://github.com/usekaneo/kaneo/compare/v2.9.5...v2.9.6) (2026-07-18)
## [2.9.5](https://github.com/usekaneo/kaneo/compare/v2.9.4...v2.9.5) (2026-07-18)


### Features

* complete task reminders and notifications ([#1399](https://github.com/usekaneo/kaneo/issues/1399)) ([813dcb3](https://github.com/usekaneo/kaneo/commit/813dcb3631649664c88b05b414f373358c720651))
## [2.9.4](https://github.com/usekaneo/kaneo/compare/v2.9.3...v2.9.4) (2026-07-17)
## [2.9.3](https://github.com/usekaneo/kaneo/compare/v2.9.2...v2.9.3) (2026-07-17)


### Bug Fixes

* **auth:** fall back for custom OAuth profile names ([#1360](https://github.com/usekaneo/kaneo/issues/1360)) ([02edfa9](https://github.com/usekaneo/kaneo/commit/02edfa915806389824d7f5232e2fa74a4443dfb8))
* **docker:** allow nginx revision rebuilds in apk pin ([#1405](https://github.com/usekaneo/kaneo/issues/1405)) ([d99d678](https://github.com/usekaneo/kaneo/commit/d99d67863add6b6fb020d9a6f0d8750bef4e1304))
* **email:** translate French workspace invitations ([#1390](https://github.com/usekaneo/kaneo/issues/1390)) ([1e99d3a](https://github.com/usekaneo/kaneo/commit/1e99d3a28c5c52f746c4364b0f6cae9ba54df229))
* load task statuses on direct page visits ([#1403](https://github.com/usekaneo/kaneo/issues/1403)) ([1ca05c4](https://github.com/usekaneo/kaneo/commit/1ca05c4c7857e5d2b64d0fc3d0442ee0015f5911))
* **web:** load status options from columns query ([#1404](https://github.com/usekaneo/kaneo/issues/1404)) ([2fbdd3c](https://github.com/usekaneo/kaneo/commit/2fbdd3cbf7ae9e442eddf65ba34e83dc6de821f3)), closes [#1402](https://github.com/usekaneo/kaneo/issues/1402)


### Features

* **i18n:** complete French translations ([#1359](https://github.com/usekaneo/kaneo/issues/1359)) ([772cbc5](https://github.com/usekaneo/kaneo/commit/772cbc5f8fa9e28ed3bf4faabdababbdeca436ac))
* **i18n:** turkish language support ([#1366](https://github.com/usekaneo/kaneo/issues/1366)) ([8806e86](https://github.com/usekaneo/kaneo/commit/8806e86f0f71833ddca9577f58f5077f5191f095))
## [2.9.2](https://github.com/usekaneo/kaneo/compare/v2.9.1...v2.9.2) (2026-07-16)


### Bug Fixes

* **api:** enforce scoped API key permissions ([#1374](https://github.com/usekaneo/kaneo/issues/1374)) ([9bedc4a](https://github.com/usekaneo/kaneo/commit/9bedc4aee161ac272f8c31d0d6a7d320b6a7c13d))
* **api:** prioritize project workspace lookup ([#1383](https://github.com/usekaneo/kaneo/issues/1383)) ([7a8320a](https://github.com/usekaneo/kaneo/commit/7a8320a783fa894cd5442bb11c7f23a3df677ca5))
* **assets:** prevent active content execution ([#1373](https://github.com/usekaneo/kaneo/issues/1373)) ([39b787a](https://github.com/usekaneo/kaneo/commit/39b787a6c2ec051d47bb4e8a9a9012ec978b31d5))
* **auth:** enforce disabled local login ([#1375](https://github.com/usekaneo/kaneo/issues/1375)) ([8c8eaf3](https://github.com/usekaneo/kaneo/commit/8c8eaf3e86a560eaa477f1af1a8fda1660bcc114))
* **auth:** protect invitation acceptance from unverified accounts ([#1386](https://github.com/usekaneo/kaneo/issues/1386)) ([a686614](https://github.com/usekaneo/kaneo/commit/a6866143f1ccf85ff84669bb9c7f5541d01ab98d))
* **auth:** require verified email for account linking ([#1387](https://github.com/usekaneo/kaneo/issues/1387)) ([4a5c818](https://github.com/usekaneo/kaneo/commit/4a5c8187de45ef1da1c4f0d4c3c6032f815d3911))
* **auth:** restore guest sign-in access ([#1391](https://github.com/usekaneo/kaneo/issues/1391)) ([d7281e1](https://github.com/usekaneo/kaneo/commit/d7281e1a20be25ab057a0a82afac1bb11e0af7b0))
* **comments:** unify API and activity storage ([#1389](https://github.com/usekaneo/kaneo/issues/1389)) ([23f8bf4](https://github.com/usekaneo/kaneo/commit/23f8bf4f05c43d4023965c80768bdc1c28aeadfc))
* **editor:** reject active embed URL schemes ([#1376](https://github.com/usekaneo/kaneo/issues/1376)) ([5630fd0](https://github.com/usekaneo/kaneo/commit/5630fd0e5fb0c56e6f40b49bdbe32a30f25e9ed2))
* **gitea:** bind webhooks to signed integration ([#1378](https://github.com/usekaneo/kaneo/issues/1378)) ([27cb25e](https://github.com/usekaneo/kaneo/commit/27cb25ea0d608d0dbde82da86b70a8bb71b1f267))
* **gitea:** restrict webhook secret access ([#1377](https://github.com/usekaneo/kaneo/issues/1377)) ([37207a0](https://github.com/usekaneo/kaneo/commit/37207a0e2cf0d4adaf4af6ee17d218b09f6ce7bf))
* **labels:** enforce task workspace boundary ([#1380](https://github.com/usekaneo/kaneo/issues/1380)) ([4f6ea91](https://github.com/usekaneo/kaneo/commit/4f6ea91d86035e8fd30262df982cb18a29bd5226))
* **mcp:** require explicit OAuth consent ([#1372](https://github.com/usekaneo/kaneo/issues/1372)) ([2c8b6d8](https://github.com/usekaneo/kaneo/commit/2c8b6d8582ef1f7c9929531e900412b29fca46c3))
* **mcp:** validate registered redirect URIs ([#1381](https://github.com/usekaneo/kaneo/issues/1381)) ([e18eb00](https://github.com/usekaneo/kaneo/commit/e18eb00e2d49d1f372a95bfd6ff8529dfecf10a0))
* **tasks:** prevent cross-workspace moves ([#1384](https://github.com/usekaneo/kaneo/issues/1384)) ([797380d](https://github.com/usekaneo/kaneo/commit/797380d2d6e4648b44295c0d13b3440d7e7e5138))
* **tasks:** prevent cross-workspace relations ([#1385](https://github.com/usekaneo/kaneo/issues/1385)) ([9c2a33b](https://github.com/usekaneo/kaneo/commit/9c2a33b613aececbb5545d7679a7a5ad2cb00979))


### Features

* standardize avatar fallback initials ([#1401](https://github.com/usekaneo/kaneo/issues/1401)) ([5cddfa1](https://github.com/usekaneo/kaneo/commit/5cddfa13019f8dfb83976913824954677be33cbb))
## [2.9.1](https://github.com/usekaneo/kaneo/compare/v2.9.0...v2.9.1) (2026-07-15)


### Bug Fixes

* add debug logging for device authorize CI failure ([d84ef47](https://github.com/usekaneo/kaneo/commit/d84ef47d7774eebe2775d29689732f8f0ecef4ce))
* address OpenAPI review feedback ([e2b0767](https://github.com/usekaneo/kaneo/commit/e2b0767781060f4a360ca69aaefacf09cf179bc2))
* **board:** reflect disabled card dragging ([8ca1cca](https://github.com/usekaneo/kaneo/commit/8ca1cca7c75ea32b0e2a64be880bded86be53248))
* **chart:** generate per-release auth secret ([1387239](https://github.com/usekaneo/kaneo/commit/138723994789a6a14fc037a465570d4d3602dfe9))
* **chart:** provide auth secret in validation matrix ([19c21f0](https://github.com/usekaneo/kaneo/commit/19c21f0115d6b948bd069fca3314846416ca644e))
* **chart:** require explicit auth secret ([3317948](https://github.com/usekaneo/kaneo/commit/331794873882870fb6828e6a82fcb63992c0d7da))
* **charts/ci:** Adding dynamic versioning in helm ci ([b768d3d](https://github.com/usekaneo/kaneo/commit/b768d3d0dcace19c168512f25c9a11e2284e24dd))
* **charts/ci:** fixing the publishing steps for helm chart ([a3b5112](https://github.com/usekaneo/kaneo/commit/a3b5112c1da8f3bfd3637adc1f8040d2ab702e20))
* **ci:** grant actions: write to trigger-helm-publish ([e78e2fc](https://github.com/usekaneo/kaneo/commit/e78e2fc02b7fb631af58e7d30b167de9d624fbe4))
* **ci:** pass inputs.version via env to github-script ([376adc6](https://github.com/usekaneo/kaneo/commit/376adc65fb3b595afab0fa42b9974277556c0de9))
* **ci:** resolving concern from qodo/coderabbit ([2a13e6e](https://github.com/usekaneo/kaneo/commit/2a13e6e6c977c8f46bc371ca2084447c8cb1d11a))
* **ci:** use  in release main-branch guard ([dc860d8](https://github.com/usekaneo/kaneo/commit/dc860d8f97fa81ada5f2bded8f1ec4a94b720a31))
* clean up drag preview on component unmount ([422baec](https://github.com/usekaneo/kaneo/commit/422baec264c5ff1cef2f6cd8a4abb6242ad9c55e))
* destructure columns from createProjectFixture in label tests ([212ff18](https://github.com/usekaneo/kaneo/commit/212ff184c18017eae37a59670cacd8870fa1f5fd))
* **docker:** stop nightly arm64 build hanging on native bcrypt ([d046087](https://github.com/usekaneo/kaneo/commit/d04608772063e6b07a4f5c0304d6a90436c1f27d))
* **docker:** update pinned nginx package ([9369771](https://github.com/usekaneo/kaneo/commit/93697712f3c0f96ab0182379cb2d809a3ce8244e))
* **docs:** validate local OpenAPI reference ([0c9fccc](https://github.com/usekaneo/kaneo/commit/0c9fcccb056a60e4bfc7e6c34caf12841e4504a9))
* guard Enter key handlers in labels dialogs with isPending state ([6c8fc8a](https://github.com/usekaneo/kaneo/commit/6c8fc8afa59c772df1de78e8c07e261237f48fd5))
* **helm:** app version fix, guard, and trigger added ([66399ae](https://github.com/usekaneo/kaneo/commit/66399aea043876757d59a1f2163e52be64ff3046))
* **i18n:** make workspace roles settings translatable ([8c8bf38](https://github.com/usekaneo/kaneo/commit/8c8bf38f9de84be15ee27b614035531d12e10c9f))
* invalidate labels query cache on workspace-level label deletion ([385cd7e](https://github.com/usekaneo/kaneo/commit/385cd7e8f06d89ea332834119602891e648c0ef7))
* **label:** cascade delete task-level label copies when workspace label is deleted ([4d9fed0](https://github.com/usekaneo/kaneo/commit/4d9fed05b6164e850740252cb38c08334ff67ad2))
* **labels:** address workspace label review ([006056c](https://github.com/usekaneo/kaneo/commit/006056c77a93df06094d8d05b35ec6647d4019a2))
* make drag preview non-interactive ([cb27ef0](https://github.com/usekaneo/kaneo/commit/cb27ef043f269f31ad55b5f641379fead2f7aade))
* prevent oversized workflow column drag preview ([#1394](https://github.com/usekaneo/kaneo/issues/1394)) ([90652d1](https://github.com/usekaneo/kaneo/commit/90652d1203e367e218ecf52b6e39da87f471f6ca))
* propagate label color changes to existing task assignments ([bbd4589](https://github.com/usekaneo/kaneo/commit/bbd45892acf8b6c78c5e8099a662f96ff0121094))
* publish label deletion events and sync to GitHub/Gitea when labels are cascaded from workspace ([94559e7](https://github.com/usekaneo/kaneo/commit/94559e72f37498393eae01d9338bf289bca20058))
* **qodo:** applying fixes recommended by qodo review ([58fbb84](https://github.com/usekaneo/kaneo/commit/58fbb84b38fb8deef3e4bfea41256a3547c5a8e9))
* replace invalid vi.Mock type references with imported Mock type ([607a3d2](https://github.com/usekaneo/kaneo/commit/607a3d26ceee4fa8a39a77f3137df2a4ab92fc5a))
* replace onClose with onOpenChange in labels settings dialogs ([ad0b0da](https://github.com/usekaneo/kaneo/commit/ad0b0daf07def5b6b09c0ccd9e508f5d1a2beb09))
* reset shared invalidate spy between useUpdateLabel tests ([c6487cd](https://github.com/usekaneo/kaneo/commit/c6487cd2fc424d4b884540c21e9986f6ab60320e))
* **review:** further updates from code review ([9334a83](https://github.com/usekaneo/kaneo/commit/9334a83df76ce58ac154575d4c15365f77e813be))
* **site:** use official Product Hunt logo ([abcc3bb](https://github.com/usekaneo/kaneo/commit/abcc3bb889f77c883aaf64ec52c22b552dd7f32e))


### Features

* add DISABLE_EMAIL_OTP_SIGN_IN for password sign-in with SMTP ([3fbdfbc](https://github.com/usekaneo/kaneo/commit/3fbdfbcdc24196bba34808f6b501afbc426ada24))
* **i18n:** add Indonesian locale ([1fe6bd0](https://github.com/usekaneo/kaneo/commit/1fe6bd0bd8875733a905fde9076c68e0168a6dad))
* **settings:** add workspace labels management page with CRUD ([e656a69](https://github.com/usekaneo/kaneo/commit/e656a698f5889c30253683df8d70e4f90815bb3d))
# [2.9.0](https://github.com/usekaneo/kaneo/compare/v2.8.0...v2.9.0) (2026-06-30)


### Bug Fixes

* **auth:** allow unverified users to accept workspace invitations ([d2f2b0f](https://github.com/usekaneo/kaneo/commit/d2f2b0f559204c4b97cd32aaff322a8cc526782d))
* **auth:** link OIDC sign-in to existing same-email accounts ([#987](https://github.com/usekaneo/kaneo/issues/987)) ([0667479](https://github.com/usekaneo/kaneo/commit/0667479cb693dc66f2fda59da564219620133884))


### Features

* **comments:** [@mention](https://github.com/mention) workspace members in task comments ([#1353](https://github.com/usekaneo/kaneo/issues/1353)) ([98184d2](https://github.com/usekaneo/kaneo/commit/98184d2611a218dc1463b5e1c3b0fa71efd9be81))
* **tasks:** notify members [@mentioned](https://github.com/mentioned) in a task description ([#1353](https://github.com/usekaneo/kaneo/issues/1353)) ([554b5ac](https://github.com/usekaneo/kaneo/commit/554b5ac9e4f21070b2901943dfead400cb864c58))
# [2.8.0](https://github.com/usekaneo/kaneo/compare/v2.7.8...v2.8.0) (2026-06-30)


### Bug Fixes

* **api:** drop malformed Better Auth schema fields from OpenAPI output ([e986f58](https://github.com/usekaneo/kaneo/commit/e986f58173a0c8c205e61c6c28dc0f90d27407c7))
* **auth:** claim device code before approve/deny (better-auth 1.6.11) ([d57a957](https://github.com/usekaneo/kaneo/commit/d57a9574d68fe618a7ffd24a13f33bf0aa2cf87a))
* **subtasks:** make the leading checkbox toggle completion ([#1352](https://github.com/usekaneo/kaneo/issues/1352)) ([7627210](https://github.com/usekaneo/kaneo/commit/762721001416fafcea0af713585f2d428d13d309))


### Features

* **mcp:** support KANEO_API_KEY for non-interactive auth ([014cc96](https://github.com/usekaneo/kaneo/commit/014cc9622b5aa527e617a6eb58944e7aa5558c7d))
* **notifications:** opt-in flag to allow private webhook destinations ([412c568](https://github.com/usekaneo/kaneo/commit/412c56879d11eaeb3ff2db0e1612e32e8c727002))
## [2.7.8](https://github.com/usekaneo/kaneo/compare/v2.7.7...v2.7.8) (2026-06-29)


### Bug Fixes

* add enabled guard to useGetTask ([b689d48](https://github.com/usekaneo/kaneo/commit/b689d48de18993be7d07db84be690cf3680490e2))
* add WebSocket keepalive pings and DB connection timeouts ([#1323](https://github.com/usekaneo/kaneo/issues/1323)) ([6ae96c6](https://github.com/usekaneo/kaneo/commit/6ae96c6d6fbbef947440c7b6baa3a712c50ed9a9))
* auto-login failure can leave the sign-in page permanently stuck on skeleton ([e29bebb](https://github.com/usekaneo/kaneo/commit/e29bebb9c5dbb7372e7e76eb498c6f40c3917dd9))
* **bug:** added normalizedApiServerUrl to resolve asset url ([5b9633e](https://github.com/usekaneo/kaneo/commit/5b9633e8402b69b6905477e377fcff93907b3d81))
* **bug:** derive fallback asset URL from request origin instead of hardcoded localhost:1337 ([686a0cb](https://github.com/usekaneo/kaneo/commit/686a0cbd3318ab324bf1b46eced045f5d2453d30))
* **command-palette:** default to planned status when creating a task from backlog ([020ec96](https://github.com/usekaneo/kaneo/commit/020ec962e44fa30f5c005289de7ca4adc8f5c7c4))
* **comment:** improve comment formatting in task event publication. ([02dec8e](https://github.com/usekaneo/kaneo/commit/02dec8e34818a0909513c405e61fe6707140936e))
* **deps:** allow @hono/node-server v2 so the [#1292](https://github.com/usekaneo/kaneo/issues/1292) upgrade takes effect ([#1313](https://github.com/usekaneo/kaneo/issues/1313)) ([b527638](https://github.com/usekaneo/kaneo/commit/b52763822bb8144a52d549151359b05ffb404fd2))
* **docker:** bump pinned nginx to 1.28.3-r4 ([97388a0](https://github.com/usekaneo/kaneo/commit/97388a0d5397e20ec1beb3b1ff03238d770104a0))
* **docs:** resolves bug 1346 ([#1350](https://github.com/usekaneo/kaneo/issues/1350)) ([709453f](https://github.com/usekaneo/kaneo/commit/709453fd87a2c5ed6fa18b924510d2b6bc5cbaf4))
* **docs:** resolving qodo suggestions ([72caad9](https://github.com/usekaneo/kaneo/commit/72caad9bd04d94767691475fd9af8efc93db5b9d))
* **docs:** updating README.md for helm chart. Replaced steps and added clear direction ([53a245d](https://github.com/usekaneo/kaneo/commit/53a245dac23f6178d963c2609731e2a63b2a7712))
* **editor:** add table row/column controls to the bubble menu ([adde63d](https://github.com/usekaneo/kaneo/commit/adde63db46b6a6d38059c262c39f1ad7f9c01b9a))
* errorCallbackURL redirect loop, empty <p>, integration test ([81c5d6a](https://github.com/usekaneo/kaneo/commit/81c5d6a8255bbbc204231404c1bd3f3efa485c2e))
* **github-integration:** surface server error text on verify failure ([781274d](https://github.com/usekaneo/kaneo/commit/781274d0af5cb683d86277275139d08f49d5e593))
* **helm:** define KANEO_POSTGRES_PASSWORD before DATABASE_URL ([#1309](https://github.com/usekaneo/kaneo/issues/1309)) ([ac43e74](https://github.com/usekaneo/kaneo/commit/ac43e74d928b564c77b27a0753b0febb83034325))
* **helm:** resolve agent reviews and suggestions ([9380e69](https://github.com/usekaneo/kaneo/commit/9380e698539271cf0ac8cad8e2e96fff34bfe5ef))
* **mcp:** guard delete_label against workspace labels ([27b8304](https://github.com/usekaneo/kaneo/commit/27b83048bd1c310688adc9c9113e57a79c554179))
* **notifications:** full-bleed inbox dropdown and drop duplicate query key ([8c1e212](https://github.com/usekaneo/kaneo/commit/8c1e21265e82b5538ea5fa0376ac003e257d03d5)), closes [#1324](https://github.com/usekaneo/kaneo/issues/1324) [#1323](https://github.com/usekaneo/kaneo/issues/1323)
* **permissions:** let members with create-only permission create tasks ([e71a8f9](https://github.com/usekaneo/kaneo/commit/e71a8f98d639a8a3a887160d0cb27d755294aedf))
* **task-relations:** distinguish "blocked by" from "blocks" ([867df7d](https://github.com/usekaneo/kaneo/commit/867df7d4b8ce4b92cec6513eaba468d910d499f8))
* **tests:** added integration tests for fix validation ([caba382](https://github.com/usekaneo/kaneo/commit/caba3829de12ba84efb9c9d8d2b5cc3bf0ae617b))
* use custom column names in webhook status reports ([#1343](https://github.com/usekaneo/kaneo/issues/1343)) ([8ef65f0](https://github.com/usekaneo/kaneo/commit/8ef65f02ad1463295eec1e2265d2a087bd1aa9f2))
* use LF line endings in husky commit-msg hook ([4a9fe04](https://github.com/usekaneo/kaneo/commit/4a9fe04a8f5dc417d6fcd24e40262aeb5360d788))


### Features

* **ci:** add helm chart publishing ([9b141f3](https://github.com/usekaneo/kaneo/commit/9b141f369e55e70b78e68925b2d4d2eaad5052e6))
* **comments:** allow users to delete their own comments ([#1322](https://github.com/usekaneo/kaneo/issues/1322)) ([02e1712](https://github.com/usekaneo/kaneo/commit/02e1712e3cce44a727fc77f524f40df423f61a34))
* custom OAuth auto login, allow disabling the Login Form ([97b2b98](https://github.com/usekaneo/kaneo/commit/97b2b98aa955fc6ee61961a98559ce427a38d015))
* **helm:** prep for helm chart publishing ([1972efa](https://github.com/usekaneo/kaneo/commit/1972efa2ae1b2690e816508877bb9a300e067a12))
* **mcp:** add task-relation and label-delete tools ([dfc2d9b](https://github.com/usekaneo/kaneo/commit/dfc2d9b0f47286d5a279fb44c12e4430c8592275))
* **notifications:** notification inbox with real-time WebSocket updates ([#1324](https://github.com/usekaneo/kaneo/issues/1324)) ([3c09c5b](https://github.com/usekaneo/kaneo/commit/3c09c5bb423116a01c2163cf200f972bc44994f2))
* support AWS IAM roles for S3 storage ([#1342](https://github.com/usekaneo/kaneo/issues/1342)) ([089a7de](https://github.com/usekaneo/kaneo/commit/089a7de9c5b14f344dd958bb06f07c23e73e9cdf))
## [2.7.7](https://github.com/usekaneo/kaneo/compare/v2.7.6...v2.7.7) (2026-05-29)


### Bug Fixes

* **ci:** build internal deps before running tests ([1c69023](https://github.com/usekaneo/kaneo/commit/1c69023f977f5282f98f052b4a2db0622996dc96))
* **ci:** route test:integration through turbo so deps are built first ([8d0cbaf](https://github.com/usekaneo/kaneo/commit/8d0cbaff44e9b882cfe776c05797d32da72652c0))
* **web:** empty unset KANEO_* placeholders so self-hosted signup works ([d9420a8](https://github.com/usekaneo/kaneo/commit/d9420a817279931d1c9c94b7406146e0b52e31e2)), closes [#1304](https://github.com/usekaneo/kaneo/issues/1304)
## [2.7.6](https://github.com/usekaneo/kaneo/compare/v2.7.5...v2.7.6) (2026-05-29)


### Bug Fixes

* **docker:** build @kaneo/permissions in web stages too ([6b8d4ca](https://github.com/usekaneo/kaneo/commit/6b8d4cae815339c0d4ac1714b785ba32b723dbf5))
* **github:** skip issues opened by the configured app bot ([9078121](https://github.com/usekaneo/kaneo/commit/9078121ab85660fcfdc596d8f1aec3f2e88b7a40))
* **permissions:** compile package to dist for prod node runtime ([75273c9](https://github.com/usekaneo/kaneo/commit/75273c9a660ff5fb0c8feba71c5d70d22642d8ad))
* **rbac:** chunk default-role seed insert to stay under bind-param cap ([365d575](https://github.com/usekaneo/kaneo/commit/365d5759b398cbec887ccb744b8f175e53f29799))


### Features

* **auth:** cloud abuse-mitigation gates for sign-up and invites ([1d44a33](https://github.com/usekaneo/kaneo/commit/1d44a33fd9e011da7a7063a9a7d780d726f9dd76))
## [2.7.5](https://github.com/usekaneo/kaneo/compare/v2.7.4...v2.7.5) (2026-05-27)


### Bug Fixes

* **auth:** widen ac to AccessControl for organization() typing ([e21c6d4](https://github.com/usekaneo/kaneo/commit/e21c6d43e0f9f82c45d5efd4060f3f6a90f4c64b))
* **ci:** use RELEASE_TOKEN PAT so release events fire downstream ([62eac52](https://github.com/usekaneo/kaneo/commit/62eac52593f67c117a5355edf96552ec24497a12))
* **columns:** allow workflow icon updates ([2f02835](https://github.com/usekaneo/kaneo/commit/2f02835c5642785d39a02f7cd54d9fdd3a667f94))
* **deps:** regenerate pnpm-lock.yaml (stale next@16 reference) ([7e86f06](https://github.com/usekaneo/kaneo/commit/7e86f069c5062e26a525d4d9aa0d83f86c7cfb86))
* **docker:** bump pinned nginx to 1.28.3-r2 in Dockerfile.kaneo ([7e7ba28](https://github.com/usekaneo/kaneo/commit/7e7ba2844251620f319e146b813071a85793af76))
* **github:** accept \n-escaped and base64-encoded GITHUB_PRIVATE_KEY ([63c060b](https://github.com/usekaneo/kaneo/commit/63c060bc74a30b167a680fd6cc1d7b8b51c41b8a)), closes [#1299](https://github.com/usekaneo/kaneo/issues/1299)
* **package:** revert version to 2.7.4 in package.json ([0ac1302](https://github.com/usekaneo/kaneo/commit/0ac1302a9c27fe6d42c656eff72a65e22abd300f))
* **rbac:** address CodeRabbit follow-up on admin promotion and sign-in flash ([c882894](https://github.com/usekaneo/kaneo/commit/c8828941ba07ac0db64e15bff94d56570bf6c167))
* **rbac:** address PR review feedback (build, tests, label permissions) ([21c0f75](https://github.com/usekaneo/kaneo/commit/21c0f754ecbcb5c253241ffc3737497cf15f983e))
* **rbac:** address Qodo re-review (admin promotion, registration, instance status) ([67eda1e](https://github.com/usekaneo/kaneo/commit/67eda1ea6c6eca01748e3d8895229bdebe090f97)), closes [#4](https://github.com/usekaneo/kaneo/issues/4) [#3](https://github.com/usekaneo/kaneo/issues/3) [#1](https://github.com/usekaneo/kaneo/issues/1) [#2](https://github.com/usekaneo/kaneo/issues/2)
* **rbac:** address review bot comments ([68a9f65](https://github.com/usekaneo/kaneo/commit/68a9f654cf5c72a7cbc9e20319a963df9e69b4b5)), closes [#2](https://github.com/usekaneo/kaneo/issues/2)
* **rbac:** validate custom-role permission JSON before authorizing ([c522001](https://github.com/usekaneo/kaneo/commit/c5220012b9c8a8522de4bda2291eaa540722acb7))
* **web:** align invite member modal styling ([81932e3](https://github.com/usekaneo/kaneo/commit/81932e31569838f1ccadaeedc6be51fd51d3cbb8))
* **web:** ensure active workspace is set when deep-linking to settings ([31cd7e0](https://github.com/usekaneo/kaneo/commit/31cd7e03ebd10519aa998161798d3d6e84a425e2))
* **web:** invalidate the right caches on workspace user role update ([a411821](https://github.com/usekaneo/kaneo/commit/a411821fb7eb6132292c6978459420abc7a0e5da))


### Features

* **rbac:** gate workspace UI on server-checked permissions ([c414432](https://github.com/usekaneo/kaneo/commit/c41443276ca783395c0ff95c568f96005501554e))
* **site:** add product hunt landing badge ([28fb3e3](https://github.com/usekaneo/kaneo/commit/28fb3e397689fe54eb04848c5fea554a4525da15))
* **web:** move members page back to workspace sidebar with new table design ([565b898](https://github.com/usekaneo/kaneo/commit/565b898c14ebf7c6419940a59e564acfeaa9d5ac))
* **web:** ownership transfer in workspace general settings ([405de6e](https://github.com/usekaneo/kaneo/commit/405de6e7caec1a23fa772a9550514313590b27f0))
* workspace RBAC with custom roles and instance admin ([039f4bb](https://github.com/usekaneo/kaneo/commit/039f4bb00f0b40ae10a00b51281bde213b098492))
## [2.7.5](https://github.com/usekaneo/kaneo/compare/v2.7.4...v2.7.5) (2026-05-27)


### Bug Fixes

* **auth:** widen ac to AccessControl for organization() typing ([e21c6d4](https://github.com/usekaneo/kaneo/commit/e21c6d43e0f9f82c45d5efd4060f3f6a90f4c64b))
* **columns:** allow workflow icon updates ([2f02835](https://github.com/usekaneo/kaneo/commit/2f02835c5642785d39a02f7cd54d9fdd3a667f94))
* **deps:** regenerate pnpm-lock.yaml (stale next@16 reference) ([7e86f06](https://github.com/usekaneo/kaneo/commit/7e86f069c5062e26a525d4d9aa0d83f86c7cfb86))
* **github:** accept \n-escaped and base64-encoded GITHUB_PRIVATE_KEY ([63c060b](https://github.com/usekaneo/kaneo/commit/63c060bc74a30b167a680fd6cc1d7b8b51c41b8a)), closes [#1299](https://github.com/usekaneo/kaneo/issues/1299)
* **rbac:** address CodeRabbit follow-up on admin promotion and sign-in flash ([c882894](https://github.com/usekaneo/kaneo/commit/c8828941ba07ac0db64e15bff94d56570bf6c167))
* **rbac:** address PR review feedback (build, tests, label permissions) ([21c0f75](https://github.com/usekaneo/kaneo/commit/21c0f754ecbcb5c253241ffc3737497cf15f983e))
* **rbac:** address Qodo re-review (admin promotion, registration, instance status) ([67eda1e](https://github.com/usekaneo/kaneo/commit/67eda1ea6c6eca01748e3d8895229bdebe090f97)), closes [#4](https://github.com/usekaneo/kaneo/issues/4) [#3](https://github.com/usekaneo/kaneo/issues/3) [#1](https://github.com/usekaneo/kaneo/issues/1) [#2](https://github.com/usekaneo/kaneo/issues/2)
* **rbac:** address review bot comments ([68a9f65](https://github.com/usekaneo/kaneo/commit/68a9f654cf5c72a7cbc9e20319a963df9e69b4b5)), closes [#2](https://github.com/usekaneo/kaneo/issues/2)
* **rbac:** validate custom-role permission JSON before authorizing ([c522001](https://github.com/usekaneo/kaneo/commit/c5220012b9c8a8522de4bda2291eaa540722acb7))
* **web:** align invite member modal styling ([81932e3](https://github.com/usekaneo/kaneo/commit/81932e31569838f1ccadaeedc6be51fd51d3cbb8))
* **web:** ensure active workspace is set when deep-linking to settings ([31cd7e0](https://github.com/usekaneo/kaneo/commit/31cd7e03ebd10519aa998161798d3d6e84a425e2))
* **web:** invalidate the right caches on workspace user role update ([a411821](https://github.com/usekaneo/kaneo/commit/a411821fb7eb6132292c6978459420abc7a0e5da))


### Features

* **rbac:** gate workspace UI on server-checked permissions ([c414432](https://github.com/usekaneo/kaneo/commit/c41443276ca783395c0ff95c568f96005501554e))
* **site:** add product hunt landing badge ([28fb3e3](https://github.com/usekaneo/kaneo/commit/28fb3e397689fe54eb04848c5fea554a4525da15))
* **web:** move members page back to workspace sidebar with new table design ([565b898](https://github.com/usekaneo/kaneo/commit/565b898c14ebf7c6419940a59e564acfeaa9d5ac))
* **web:** ownership transfer in workspace general settings ([405de6e](https://github.com/usekaneo/kaneo/commit/405de6e7caec1a23fa772a9550514313590b27f0))
* workspace RBAC with custom roles and instance admin ([039f4bb](https://github.com/usekaneo/kaneo/commit/039f4bb00f0b40ae10a00b51281bde213b098492))
## [2.7.4](https://github.com/usekaneo/kaneo/compare/v2.7.3...v2.7.4) (2026-05-18)


### Bug Fixes

* **api:** restore atomic ownership check on activity comment writes ([12e9b94](https://github.com/usekaneo/kaneo/commit/12e9b942a1e78d48f2222908eb8267205855da27))


### Features

* **api:** add S3 key prefix support and auto-delete orphaned assets ([#1258](https://github.com/usekaneo/kaneo/issues/1258)) ([84fd6bd](https://github.com/usekaneo/kaneo/commit/84fd6bd38bd2f5f670502e79f28b99783436f10d))
## [2.7.3](https://github.com/usekaneo/kaneo/compare/v2.7.2...v2.7.3) (2026-05-18)


### Bug Fixes

* **api:** resolve issue [#1231](https://github.com/usekaneo/kaneo/issues/1231) ([#1257](https://github.com/usekaneo/kaneo/issues/1257)) ([94072ee](https://github.com/usekaneo/kaneo/commit/94072eec4c81fe5d4fb041d0a25342fa576431ff))
* **db:** add missing foreign key indexes ([#1226](https://github.com/usekaneo/kaneo/issues/1226)) ([09742d4](https://github.com/usekaneo/kaneo/commit/09742d4452babdde1ebb359d290d04b0723384ed))
* emit task.status_changed for git webhook status updates ([#1263](https://github.com/usekaneo/kaneo/issues/1263)) ([89c8207](https://github.com/usekaneo/kaneo/commit/89c8207052cea65cc1be7491651179cd41f98a4d))
* inconsistent import extension ([4b5afc9](https://github.com/usekaneo/kaneo/commit/4b5afc9abb93a6c0d12d7c370152796691ff7a1c))
* properly construct WS URL ([13d2ecc](https://github.com/usekaneo/kaneo/commit/13d2eccca3ced31cdbce55a022daa9f6f9c31197))
* remove duplicate import tasks modal close button ([#1264](https://github.com/usekaneo/kaneo/issues/1264)) ([4f4d36b](https://github.com/usekaneo/kaneo/commit/4f4d36b69602cbbeba8ec0608745b1a687fb6e97))
* replace em dash with hyphen in titles and metadata ([00b1f86](https://github.com/usekaneo/kaneo/commit/00b1f865f89e410e62936612cf4310af00e1060e))
* **web:** Fix websocket path ([#1228](https://github.com/usekaneo/kaneo/issues/1228)) ([7059683](https://github.com/usekaneo/kaneo/commit/70596832d4eb325001a661cfadf6d4044a73863e))


### Features

* **i18n:** add Korean (ko-KR) translation ([#1229](https://github.com/usekaneo/kaneo/issues/1229)) ([cb5f607](https://github.com/usekaneo/kaneo/commit/cb5f607a4901b3275885c0bf62e232bbe92b19d5))
* **site:** add Product Hunt launch badge to hero ([6d33c9e](https://github.com/usekaneo/kaneo/commit/6d33c9e37a53c83e5bb635ecfb18aa0df9293464)), closes [#141](https://github.com/usekaneo/kaneo/issues/141) [#124](https://github.com/usekaneo/kaneo/issues/124) [#140](https://github.com/usekaneo/kaneo/issues/140)
## [2.7.2](https://github.com/usekaneo/kaneo/compare/v2.7.1...v2.7.2) (2026-05-05)


### Features

* **chart:** add kaneo.extraEnv for arbitrary env vars ([1cfa2e9](https://github.com/usekaneo/kaneo/commit/1cfa2e92d446976ffca4964a40d578fa5db1f386)), closes [#1203](https://github.com/usekaneo/kaneo/issues/1203)
## [2.7.1](https://github.com/usekaneo/kaneo/compare/v2.7.0...v2.7.1) (2026-05-04)


### Bug Fixes

* broadcast task-relation.refresh on status update. For task details view updates ([ffa30b8](https://github.com/usekaneo/kaneo/commit/ffa30b8d5cb0cd8d800d7e4071336973d5dae591))
* bulkUpdateTasks never fires WebSocket events ([a7348d5](https://github.com/usekaneo/kaneo/commit/a7348d5f4be9afb2d6d9cca06596ef46a53ba4f2))
* codeRabbit suggetions ([9cd7a08](https://github.com/usekaneo/kaneo/commit/9cd7a08159a9056019f724aca1abf1c549404e71))
* codeRabbit suggetions applied ([ebdd208](https://github.com/usekaneo/kaneo/commit/ebdd2085d6db30023ff84519f78c3e944f86c867))
* copy task link ([e6725de](https://github.com/usekaneo/kaneo/commit/e6725de2704dc7cea1610495405c66796fbe5790))
* feature_request.yml ([7e857a8](https://github.com/usekaneo/kaneo/commit/7e857a8bd4c078d04f49e32eb60639e67b384cab))
* get /api/oauth/id-token is implemented inline ([916ddd8](https://github.com/usekaneo/kaneo/commit/916ddd8fceb213685858deb3aefcdbdbc1d72f10))
* hardcoded "done" check for strike-through styling ([cd0c119](https://github.com/usekaneo/kaneo/commit/cd0c11982678a67063d09fe30c4e8e50f08e2fdc))
* missing projectId in WS broadcast ([3b60821](https://github.com/usekaneo/kaneo/commit/3b60821cdf28545c17f546828ee45840f27146f7))
* missing properties of Task type ([3d8305d](https://github.com/usekaneo/kaneo/commit/3d8305d8802d72397a438cf02c70d7a1e73b89c7))
* move task ([96558f7](https://github.com/usekaneo/kaneo/commit/96558f74e572fc29af6ce86362128b921af0792d))
* move WebSocket endpoint under API path. For new single docker image ([d65c242](https://github.com/usekaneo/kaneo/commit/d65c242a83efd6bd1fccccd712bcc4d388219112))
* project membership authorization check to the WebSocket /ws/:projectId endpoint ([5dfb48b](https://github.com/usekaneo/kaneo/commit/5dfb48b549ab6c1d6a928ba67dfa4a02ae4532f8))
* some CodeRabbit suggetions ([0cf537f](https://github.com/usekaneo/kaneo/commit/0cf537ffa70745132ecff2d5371f745e1ef9a7aa))
* **type:** broadcastAdapter is defined as an interface ([7de2dec](https://github.com/usekaneo/kaneo/commit/7de2dec8416c7036d4b69f5976784b6dd5f4186b))
* unused project route ([cf40cdc](https://github.com/usekaneo/kaneo/commit/cf40cdcfc0f2346b825f929a28b6a46160f6cd77))
* update healthcheck URL to use 127.0.0.1 ([a02a79e](https://github.com/usekaneo/kaneo/commit/a02a79e8f3740b2f6967453f1e8db0616dbb6213))
* use correct column slug property ([a99011c](https://github.com/usekaneo/kaneo/commit/a99011c0bd8bb930d10a7924f034d3064460fb72))
* webSocket retry counter not reset on project change ([a850f5b](https://github.com/usekaneo/kaneo/commit/a850f5b37093de7a4f7bd5e343a38a1873eb40a3))


### Features

* add redis sentinal and cluster support ([9a80aa8](https://github.com/usekaneo/kaneo/commit/9a80aa8d5fe7ab44686e22db23d4aa8e084a77c1))
* add Redis-backed broadcast adapter for WebSocket scaling ([3261494](https://github.com/usekaneo/kaneo/commit/326149400a865de53953fccd9c8a20424e06dd09))
* add websockets for realtime collaboration ([b94d362](https://github.com/usekaneo/kaneo/commit/b94d3625444e9b9148ac573d41af2a9b3ee3917b))
* custom logout url for automatic logout from idp ([e6cae2a](https://github.com/usekaneo/kaneo/commit/e6cae2a0c8039b7d47e0cba4a48f0d7681a69e62))
* import/export task re-enabled ([d8a8347](https://github.com/usekaneo/kaneo/commit/d8a8347fc4d54403935da7350cceb8927a3128f0))
* **ui:** move create task to top and display permanently ([7f6a9c5](https://github.com/usekaneo/kaneo/commit/7f6a9c565f38b32719054379a0dc70775892b1f8))
* **web:** 404 not found page for task page ([137b91f](https://github.com/usekaneo/kaneo/commit/137b91fffe59807037ca8a714f6d613b19e0b188))


### Reverts

* Revert "chore(release): v2.7.1" ([bd6a08b](https://github.com/usekaneo/kaneo/commit/bd6a08b939ab79ae2b223cfbaa6df529aa03d6c7))
# [2.7.0](https://github.com/usekaneo/kaneo/compare/v2.6.9...v2.7.0) (2026-05-01)


### Bug Fixes

* **deploy:** aligning .env.sample ([d7037de](https://github.com/usekaneo/kaneo/commit/d7037deea0463baf46205b3fca654edb15266980))
* **deploy:** double-slash bug in url ([0a8c945](https://github.com/usekaneo/kaneo/commit/0a8c945cdf3414c479faa60768481b714317fb9b))
* **deploy:** env.sh fails editing nginx-qodo ([f62d459](https://github.com/usekaneo/kaneo/commit/f62d459467b0a96e8c5c63b95eb10ae971b02c32))
* **deploy:** fix Biome error in runner ([d3946b6](https://github.com/usekaneo/kaneo/commit/d3946b63ed9e6291958b44864ef7cb3969058b07))
* **deploy:** fix entrypoint exit codes, scan triggers, and docs drift ([47ff644](https://github.com/usekaneo/kaneo/commit/47ff644da544e041100a0d34b22f906f77e9da97))
* **deploy:** Helm update to avoid losing CORS allowlist ([2019d5e](https://github.com/usekaneo/kaneo/commit/2019d5e33ac34e5c68f9ac5e8886fec074675f52))
* **deploy:** missing mcp well-known routes ([90e7551](https://github.com/usekaneo/kaneo/commit/90e7551ae8a6cf552ee2b07e3f119962d53d8bca))
* **deploy:** nit pick ([568126d](https://github.com/usekaneo/kaneo/commit/568126d7237960d2dfcf8c5faf5175e0afae5ee5))
* **deploy:** pin nginx to 1.28.3-r0 for reproducible builds ([a1cfe7b](https://github.com/usekaneo/kaneo/commit/a1cfe7b890ff6089415121fed6b12a86cf8c152a))
* **deploy:** preserve status of process that failed ([e333f52](https://github.com/usekaneo/kaneo/commit/e333f52040dece0ff5698fe14a1c79946ba69a06))
* **deploy:** removing hardcord postgres ports-but really should be 5432 be default ([71c9873](https://github.com/usekaneo/kaneo/commit/71c9873d4c15a4c4ee7e08fc2108794d968be138))
* **deploy:** resolve CR PR notes ([6a5e84d](https://github.com/usekaneo/kaneo/commit/6a5e84d1d223d3f6ec89e13ebce48c429b8d4ae4))
* **deploy:** restore postgres host port 5432 in compose and docs ([9dcf712](https://github.com/usekaneo/kaneo/commit/9dcf7120d24ec149ee3ee57a231d70325cb0035f))
* **deploy:** whitespace in env.example ([5852c24](https://github.com/usekaneo/kaneo/commit/5852c2436eb06b0803141998b8d57f38fc465130))
* run apikey migration after drizzle and drop user_id not null ([5dfb52a](https://github.com/usekaneo/kaneo/commit/5dfb52a01d3ffec4aaec9964edeab4f47480633d))


### Features

* **deploy:** add single kaneo container combining API and web ([4edba3e](https://github.com/usekaneo/kaneo/commit/4edba3e76b039a9bbbe0613b350879fcaaa925dc))
* **deploy:** reduce required env vars for combined image ([d334bda](https://github.com/usekaneo/kaneo/commit/d334bda1268ec073ac8e2de5ae756153ec08289e))
* **deploy:** refactor Helm chart and drim docs to single kaneo image ([bfa651e](https://github.com/usekaneo/kaneo/commit/bfa651e78a37642cbce4238d3c6fceabf0042d66))
## [2.6.9](https://github.com/usekaneo/kaneo/compare/v2.6.8...v2.6.9) (2026-04-21)


### Bug Fixes

* .github/ISSUE_TEMPLATE/bug_report.yml ([4f4c33e](https://github.com/usekaneo/kaneo/commit/4f4c33e1b326edae3185cd80f8992c9bdd1116c9))
* align task list checkboxes to top ([9d44ba7](https://github.com/usekaneo/kaneo/commit/9d44ba708b5addc72548142262da2beead0e7450))
* restore board label filters after reload ([af09695](https://github.com/usekaneo/kaneo/commit/af09695239ac1a254f79b7971f09de2de1406cc7))
* **ui:** align task label text vertically ([abb0ae2](https://github.com/usekaneo/kaneo/commit/abb0ae20661334e44158ee9bfa575e6f43563c9f))
* **web:** sync task label mutations into tasks cache ([fb504d3](https://github.com/usekaneo/kaneo/commit/fb504d3c99d090bde866bb892b2a54b66720ffec))


### Features

* add configurable first day of week ([3e532e6](https://github.com/usekaneo/kaneo/commit/3e532e606c4e9fd64eb489fe1c72f8accc1b958a))
## [2.6.8](https://github.com/usekaneo/kaneo/compare/v2.6.7...v2.6.8) (2026-04-13)


### Features

* **nginx:** update well-known endpoints to serve MCP OAuth discovery JSON ([f8df338](https://github.com/usekaneo/kaneo/commit/f8df338429a33c0b84aeb3a8602d912a5fc8fcc2))
## [2.6.7](https://github.com/usekaneo/kaneo/compare/v2.6.6...v2.6.7) (2026-04-13)


### Bug Fixes

* **docker:** update nginx configuration for environment variable handling ([a693fd6](https://github.com/usekaneo/kaneo/commit/a693fd6095b281392059da9ffff96c075a805166))
## [2.6.6](https://github.com/usekaneo/kaneo/compare/v2.6.5...v2.6.6) (2026-04-13)


### Features

* **api:** add mcp redirects ([491fa81](https://github.com/usekaneo/kaneo/commit/491fa817a5d6a6d1887b1bb3ad9fff99c4156329))
## [2.6.5](https://github.com/usekaneo/kaneo/compare/v2.6.4...v2.6.5) (2026-04-13)


### Bug Fixes

* **api:** remove trailing '/api' from KANEO_API_URL in routing ([d311f8c](https://github.com/usekaneo/kaneo/commit/d311f8c333cc78f477418e431dad5db1c93f899c))
## [2.6.4](https://github.com/usekaneo/kaneo/compare/v2.6.3...v2.6.4) (2026-04-13)


### Features

* **mcp:** add OAuth 2.0 well-known endpoints for authorization server ([a271249](https://github.com/usekaneo/kaneo/commit/a271249a12c10ab7f651c07c2d01855bb191b87c))
## [2.6.3](https://github.com/usekaneo/kaneo/compare/v2.6.2...v2.6.3) (2026-04-13)


### Features

* **mcp:** implement device authorization flow with polling mechanism ([4858952](https://github.com/usekaneo/kaneo/commit/485895241cfd7ff0dedc98d6cf852fba64f6732d))
## [2.6.2](https://github.com/usekaneo/kaneo/compare/v2.6.1...v2.6.2) (2026-04-13)


### Bug Fixes

* **api:** simplify visit function in normalizeEmptyAndEnumSchemas ([a00592e](https://github.com/usekaneo/kaneo/commit/a00592e0325540c9ee1f5e4027dafdb5a3204717))


### Features

* **mcp:** implement Model Context Protocol server with HTTP and stdio support ([e402fe1](https://github.com/usekaneo/kaneo/commit/e402fe16928e6075a1251ba068380890b3c825e7))
## [2.6.1](https://github.com/usekaneo/kaneo/compare/v2.6.0...v2.6.1) (2026-04-12)


### Bug Fixes

* **api:** avoid checksum query params in presigned S3 uploads ([d798772](https://github.com/usekaneo/kaneo/commit/d79877238d653aaf3ed3b637cdb56de0f72863ad))
* **docs:** update OpenAPI URL to use the production endpoint ([2b52824](https://github.com/usekaneo/kaneo/commit/2b5282474b28aaa5f97ae092126de692dbfa41b2))
* **task:** load sidebar status metadata from columns and restore default status i18n ([7d65de7](https://github.com/usekaneo/kaneo/commit/7d65de722db0bce6ea995367e181ab8c22c2a63c))
* **task:** use renamed project column names in status popovers ([436a14e](https://github.com/usekaneo/kaneo/commit/436a14e4c3d5ce2721cde24556c17c9f81fa75be))
* **web:** show all workspace members in assignee popovers ([1448bfe](https://github.com/usekaneo/kaneo/commit/1448bfe429885b82ba45100239b1b1b469a6aed6))


### Features

* **api:** add normalizeEmptyAndEnumSchemas function for OpenAPI spec processing ([13c544d](https://github.com/usekaneo/kaneo/commit/13c544d1a5e272c0c7ee0f4d57f59822dc2b9de7))


### Performance Improvements

* **web:** incrementally render assignee popover members ([4526548](https://github.com/usekaneo/kaneo/commit/452654871ea42a49d103925e4d29de8ff4e68825))
# [2.6.0](https://github.com/usekaneo/kaneo/compare/v2.5.3...v2.6.0) (2026-04-07)


### Bug Fixes

* address CodeRabbit review comments ([26735be](https://github.com/usekaneo/kaneo/commit/26735bebae419060bd09194eeeac91c3f6b6fb85))
* apps/api/Dockerfile to reduce vulnerabilities ([ef0ad52](https://github.com/usekaneo/kaneo/commit/ef0ad52549cfd0628321b71db44e80948d1e5ea3))
* downgrade dependabot/fetch-metadata to version 2 ([d53164e](https://github.com/usekaneo/kaneo/commit/d53164e2439c2763ebf56a11e0b265735c98537e))
* fix dist url ([9c2d9af](https://github.com/usekaneo/kaneo/commit/9c2d9af2bf7080d6164d893ef63ac39c519455ef))
* **mcp:** guard device-flow polling and project fallback types ([037ece5](https://github.com/usekaneo/kaneo/commit/037ece5138bbbee87c3356b0dd7ff4f9772bf6ce))
* **mcp:** harden auth and tool validation ([cf0a832](https://github.com/usekaneo/kaneo/commit/cf0a832f63e785d3cfb49f7e52c5fd9882a01e3f))
* **mcp:** harden auth, timeouts, and project update payloads ([64b912f](https://github.com/usekaneo/kaneo/commit/64b912f8cf6dbead379dd71474218146668f6c21))
* **mcp:** harden install merge, prompts, and device code validation ([f1ef068](https://github.com/usekaneo/kaneo/commit/f1ef0689c426b4e75b653c2f7b07d69138caf0a0))
* **mcp:** harden project update/auth timeout/install chmod ([b18dfa8](https://github.com/usekaneo/kaneo/commit/b18dfa8e635de712a0701d75067355f79f2f4a36))
* **mcp:** tighten install validation, merge errors, and config parsing ([7179269](https://github.com/usekaneo/kaneo/commit/71792690f45171ffe93defa9ad56e85c3f00090f))
* **mcp:** validate custom path in resolveTargetConfigPath ([1a64c25](https://github.com/usekaneo/kaneo/commit/1a64c25a2b60bf97d02544372d58832555eca670))
* persist project icon from general settings ([e12861e](https://github.com/usekaneo/kaneo/commit/e12861e29c7c899f200b86b03efc1d80e47bbf9c))
* use refs for comment submit/cancel shortcuts in TipTap handler ([a592d0a](https://github.com/usekaneo/kaneo/commit/a592d0a6b88ea0df664c66752711de858706263b))
* **web:** prefer column.name over slug-derived label in move popover ([daf3b73](https://github.com/usekaneo/kaneo/commit/daf3b7369fd2c32bfa34b3f7bd8959f25f3ee2b9))
* **web:** repair comment timestamp tooltip ([fbcf91d](https://github.com/usekaneo/kaneo/commit/fbcf91d9ac16dce0ef38e32dfc62029b01240c06))
* **web:** use column.id in task move popover ([39e2dfa](https://github.com/usekaneo/kaneo/commit/39e2dfae265f26c8d6d888a560f50ab2d5d58b3f))


### Features

* add kaneo mcp app ([a9fffc2](https://github.com/usekaneo/kaneo/commit/a9fffc2236eecae9b6e99c32a94b8de04a9ffa7a))
* **docs:** add mcp docs ([f6940ed](https://github.com/usekaneo/kaneo/commit/f6940ed20814502a4df2593b309133dde57bef3a))
* **i18n:** add Russian and Ukrainian locales ([b1ac92a](https://github.com/usekaneo/kaneo/commit/b1ac92a410cc1c6eecba3d7f58a3b73f1b1e4bcd))
* **mcp:** add interactive installer ([5dd5fd4](https://github.com/usekaneo/kaneo/commit/5dd5fd424fd4cb79571bdf963a2b95897eef3abc))
* **mcp:** harden install/auth tools and align device auth docs ([d7b4cda](https://github.com/usekaneo/kaneo/commit/d7b4cda244e81e919b597448489a5e3fc510dd13))
* **mcp:** support multi-target installer ([6ab96ea](https://github.com/usekaneo/kaneo/commit/6ab96ea61bde30ac12dcb2ab43022907bf605556))
* new docs for mcp; allow mcp by default ([5adb647](https://github.com/usekaneo/kaneo/commit/5adb647d527fe65ef4486c26dc5d45cf848ca98f))
* separate github sso and integration ([dc4c67d](https://github.com/usekaneo/kaneo/commit/dc4c67dd45c82155b730fc7a4c4b0b3ad7cc198b))
* **web:** show exact comment timestamp on relative time hover ([ba8cbfe](https://github.com/usekaneo/kaneo/commit/ba8cbfedfc834e78b1d5b732e55a005b586b9bd9))
## [2.5.3](https://github.com/usekaneo/kaneo/compare/v2.5.2...v2.5.3) (2026-04-03)


### Bug Fixes

* **api,test:** preserve bearer sessions on auth routes ([c398a64](https://github.com/usekaneo/kaneo/commit/c398a6444e1c85050318797018027376db0ad198))
* **api:** harden auth error handling and device query parsing ([a71932c](https://github.com/usekaneo/kaneo/commit/a71932c24cfbe343b09cd6c91ac09c6dda9ee01c))
* **api:** reject unauthenticated cookie fallback in asset auth ([50806f1](https://github.com/usekaneo/kaneo/commit/50806f19860efcb7e1274e55255a7e59fe8ca11a))
* **api:** reorder notification project migration constraint ([47224b3](https://github.com/usekaneo/kaneo/commit/47224b393fac05befa74e6aa7d6a6ece87431dff))
* **api:** tighten bearer parsing and initialize api auth email ([7b750d8](https://github.com/usekaneo/kaneo/commit/7b750d84252357c7a97c1b79fcae602f7a3c495b))
* Applied suggestions ([c67f66d](https://github.com/usekaneo/kaneo/commit/c67f66d29cdb3f7c853bb6a05317deed3bc660d2))
* enable all configured notification channels ([70afa9d](https://github.com/usekaneo/kaneo/commit/70afa9df7eb89e100599743602dd90876ebcb52b))
* fix device auth route validation and bearer handling ([505e1ff](https://github.com/usekaneo/kaneo/commit/505e1ff93617b8318dad3fc42d4c6704b2a9438b))
* harden secret encryption guard and normalize error handling ([9634b59](https://github.com/usekaneo/kaneo/commit/9634b592b7b09482341f1dba8e430ad15b493b1d))
* notification preference schema bootstrap ([795d10e](https://github.com/usekaneo/kaneo/commit/795d10e2f079108a101ea8dada905386d5a0013e))
* notification preferences secrets and locale strings ([4f349ec](https://github.com/usekaneo/kaneo/commit/4f349ec8101e3a5ba170ff7d114f28c60edfd26f))
* read workspace description from organization field ([343d124](https://github.com/usekaneo/kaneo/commit/343d1246006ba395ca21e206f96d3f2a56fb256b))
* show all board columns on public project link ([be52d66](https://github.com/usekaneo/kaneo/commit/be52d66ecee8f5355822f12213464ca74c38b4e0))
* Sort imports ([b1a73d7](https://github.com/usekaneo/kaneo/commit/b1a73d73fce66b70bb42991a3d358263572d0484))
* stop column migration from restoring deleted default columns ([dd9d038](https://github.com/usekaneo/kaneo/commit/dd9d0384ef3f557ee1c1f7def6936368e9a708fb))
* update lodash to version 4.18.0 ([79edbff](https://github.com/usekaneo/kaneo/commit/79edbffcab7824d9838e81b3adce529f38eb18a6))


### Features

* add account notification delivery settings ([4ed1d98](https://github.com/usekaneo/kaneo/commit/4ed1d98a76de3c46ba41821aa5dc4d1829105910))
* add coss primitives documentation and rules ([b313a15](https://github.com/usekaneo/kaneo/commit/b313a15ce3128f63113626dd2554b9b5d3d1b7af))
* add due date reminders scheduler ([aeb345e](https://github.com/usekaneo/kaneo/commit/aeb345ee6d4d2adf62951b198533586a7ce30903))
* add project settings to sidebar project menu ([c1425a6](https://github.com/usekaneo/kaneo/commit/c1425a632106ad8b40921ee76e89319de9ca7f33))
* Add Spanish support ([b82513e](https://github.com/usekaneo/kaneo/commit/b82513e850a54a736c4da43c3b0ee7a65d9179aa))
* add user-based Gotify notifications ([28bcfcf](https://github.com/usekaneo/kaneo/commit/28bcfcfd5c172c304dd999e1de5ef2958f925c3b))
* **auth:** add device authorization flow for CLI and external apps ([6f3f8c3](https://github.com/usekaneo/kaneo/commit/6f3f8c3ca83f297b5b6d91fc375d3f38394ffc62))
* **docs:** add otp rfc 8628 to docs ([08a47a6](https://github.com/usekaneo/kaneo/commit/08a47a68cc24f53bf55d3b52eb38684f577a62bb))
* Finished translations ([7fb800c](https://github.com/usekaneo/kaneo/commit/7fb800c81bd85192dac7c162572c83f65e66fef2))
* harden notification prefs schema, delivery, OpenAPI, and i18n ([88d57ff](https://github.com/usekaneo/kaneo/commit/88d57ff3912eff6d29ca930d0006cee716a9e2e5))
* Include Spanish in language selector ([bd72f74](https://github.com/usekaneo/kaneo/commit/bd72f7431895b7d6e573086829514bd1ed7dfdc6))
* Init es-ES translations ([abee64c](https://github.com/usekaneo/kaneo/commit/abee64c3c9ff57413817ff2d12a423305c8a4224))
* More translations ([2cec245](https://github.com/usekaneo/kaneo/commit/2cec245634ce47587b3fbeba820c7b1178231c62))
* Webhook translations ([fdc6f7e](https://github.com/usekaneo/kaneo/commit/fdc6f7e499c2de1771cdfdcb7bd8e9094a1dd7df))
## [2.5.2](https://github.com/usekaneo/kaneo/compare/v2.5.1...v2.5.2) (2026-04-02)


### Bug Fixes

* accept dbOrTx, add subscribeToEvent, fix status lookup,error handling, error toast, french ([2ce9f59](https://github.com/usekaneo/kaneo/commit/2ce9f590523b8cdd910e638faeff25add6109e4c))
* **api:** create projects transactionally ([f15d34c](https://github.com/usekaneo/kaneo/commit/f15d34c6f2219c43a167043e677f9a6adf718e40))
* **api:** document health route and harden asset auth handling ([704376e](https://github.com/usekaneo/kaneo/commit/704376e440b8822b20fb18787dfa7f033ab723da))
* **ci,github:** tighten workflow token scope and preserve zero task numbers ([a56e8cd](https://github.com/usekaneo/kaneo/commit/a56e8cdd66d163365b79f7374ba46d384a676ded))
* **ci:** exclude coverage output from biome checks ([940f00f](https://github.com/usekaneo/kaneo/commit/940f00f34534746f8d3dd23ab4bcdc2e5c22bdd9))
* **ci:** mock email package in integration tests ([77646fc](https://github.com/usekaneo/kaneo/commit/77646fc456044a87731aac6cdddcf985cb636d9d))
* **ci:** use postgres admin db for tests ([be216d6](https://github.com/usekaneo/kaneo/commit/be216d6092f2f8e580bca5a516ad523ec35b6f61))
* **github:** only ignore missing label removals ([399c797](https://github.com/usekaneo/kaneo/commit/399c7977d72326955ed1f149d45c58991c374a2b))
* **github:** preserve zero-valued task numbers ([4f370aa](https://github.com/usekaneo/kaneo/commit/4f370aaca4eb4b339059408ffa78fe1c624f2600))
* **libs:** strip trailing slash before appending /api in resolveApiBaseUrl ([6edf7cf](https://github.com/usekaneo/kaneo/commit/6edf7cfaf1177dfcda2f8924fedb5f6913ec4283))


### Features

* **api:** set userEmail for API key auth and document public routes ([fedd40a](https://github.com/usekaneo/kaneo/commit/fedd40a0657313451042471e1dcd03943b45f2e0))
* **ci:** add api integration scaffolding ([9665488](https://github.com/usekaneo/kaneo/commit/9665488a1d55c080dcd09af56c97a2338ae99e18))
* **ci:** add api project integration harness ([8559555](https://github.com/usekaneo/kaneo/commit/8559555e5542c43c00599c085c07797b2a9e2bc0))
* **ci:** add api task integration tests ([831effd](https://github.com/usekaneo/kaneo/commit/831effdcc9f60d57e2bee6428139dd66272fa9b6))
* **ci:** add api vitest suite ([621c861](https://github.com/usekaneo/kaneo/commit/621c8613dbbb54233af0c8801418aef5cf5b2c7a))
* **ci:** add lint and unit workflow ([d83e642](https://github.com/usekaneo/kaneo/commit/d83e6428129eb388a333e577645dc48fdd134ee3))
* **ci:** disable default api unit coverage and add test:coverage script ([b773513](https://github.com/usekaneo/kaneo/commit/b773513cb89f71ddf7011399e8d81064da274fa8))
* **ci:** extract api app startup ([95b8c47](https://github.com/usekaneo/kaneo/commit/95b8c4730ee840d6bd9ec83f61f9efd921286cb3))
* **test:** add label api integration tests and readme ([528afc3](https://github.com/usekaneo/kaneo/commit/528afc3d16dceb611b7712defc5fb0eb767b23df))
* **test:** add otp email template render smoke test ([ec05672](https://github.com/usekaneo/kaneo/commit/ec05672ac9532133ce19245ce57484c0095b3d26))
* **test:** add vitest config and initial web unit tests ([05fe0fb](https://github.com/usekaneo/kaneo/commit/05fe0fb340cf0e1eafa2352f1c449438ea9109cf))
* **test:** extract resolveApiBaseUrl and add libs unit tests ([2476481](https://github.com/usekaneo/kaneo/commit/2476481f97f6b959cf87d9fb5f5ed4af6fe848bf))
* **web:** move-task popover on task toolbar with readable select labels ([7b747eb](https://github.com/usekaneo/kaneo/commit/7b747eb97b734c6330bc4c3c16164cff069fd0ff))
## [2.5.1](https://github.com/usekaneo/kaneo/compare/v2.5.0...v2.5.1) (2026-04-01)


### Bug Fixes

* **api:** dedupe task numbers before unique constraint in migration 0021 ([c9bc61b](https://github.com/usekaneo/kaneo/commit/c9bc61b750c955fb349ccfe6b35b7f9982d8ef9d))
# [2.5.0](https://github.com/usekaneo/kaneo/compare/v2.4.4...v2.5.0) (2026-04-01)


### Bug Fixes

* **api:** align integration response contracts ([d527943](https://github.com/usekaneo/kaneo/commit/d527943f6159d6db5d371c06100f10b340e86537))
* **api:** handle duplicate activity and label rows on integration inserts ([83e635a](https://github.com/usekaneo/kaneo/commit/83e635aad1a88e6331904349974a2503f9c83bb1))
* **api:** harden Gitea import, API client, and webhooks ([229a4bb](https://github.com/usekaneo/kaneo/commit/229a4bb1ec48d4720c463d82c0059476cd1fea1d))
* **api:** harden gitea integration imports ([9db74f9](https://github.com/usekaneo/kaneo/commit/9db74f96a8d4548e7aa8d1c83bbe355f6d0ed613))
* **api:** harden gitea webhook sync ([a25d305](https://github.com/usekaneo/kaneo/commit/a25d30530143f64313b61661205c39c2294fc284))
* **api:** harden telegram integration config handling ([aabc145](https://github.com/usekaneo/kaneo/commit/aabc1454160a57d0061526af929748d9971c9aa3))
* **api:** harden workspace access JSON body parsing ([11c1115](https://github.com/usekaneo/kaneo/commit/11c1115f76aebbb8e90ef76f38847c58bfbe8566))
* **backlog:** simplify label rendering in dropdown menu ([f2bcf3c](https://github.com/usekaneo/kaneo/commit/f2bcf3c360e6650670241394da569bd875c3b764))
* **gitea-api:** harden webhook and sync handling ([265555a](https://github.com/usekaneo/kaneo/commit/265555a5e71b897d31c3c50b112eebcefcfeac77))
* **gitea-web:** tighten verification and repository browser behavior ([e0fc19c](https://github.com/usekaneo/kaneo/commit/e0fc19cca8220051625f706669b199000011c8e6))
* **gitea:** align fetch timeout, label api bodies, and webhook events ([c2ff123](https://github.com/usekaneo/kaneo/commit/c2ff123358c4b03f24931cc4692557dd563cf8eb))
* **gitea:** map upstream errors, tighten sync, and fix bulk labels ([3fb52f4](https://github.com/usekaneo/kaneo/commit/3fb52f44289a93e2ee9ebb88727fccfaa422e384))
* **i18n:** translate gitea integration labels ([5f7c47c](https://github.com/usekaneo/kaneo/commit/5f7c47c74f1a76cebfddbf3a9d9fcaf91f1881dc))
* make macedonian first language ([5cc0972](https://github.com/usekaneo/kaneo/commit/5cc097282ee4017310f5c01cb9bc36874e1f8a12))
* remove inner css styling for tailwind class ([14ebf40](https://github.com/usekaneo/kaneo/commit/14ebf407fe453817564c3341cb1c8cf8483226cd))
* remove unnecessary testing changes ([cd7bd4c](https://github.com/usekaneo/kaneo/commit/cd7bd4c470fc8eb1cd72320a89d13c7fed32d774))
* resolve label alignment issues ([1b1b290](https://github.com/usekaneo/kaneo/commit/1b1b290d3e1237f2d994a610b037eb09771bed06))
* **telegram:** harden integration validation and error handling ([2109592](https://github.com/usekaneo/kaneo/commit/210959284b96e8785cc522251ec3322b026479d7))
* **telegram:** redact sensitive config, avoid re-enabling, and skip no-op updates ([f3debeb](https://github.com/usekaneo/kaneo/commit/f3debeb4512c4672326b6763454f1707dc1d6e4e))
* **web:** isolate active workspace per tab via URL ([3b057b6](https://github.com/usekaneo/kaneo/commit/3b057b601408229bee30f35c244c72ee2d5f18ef))
* **web:** protect gitea webhook secrets ([b02890d](https://github.com/usekaneo/kaneo/commit/b02890d67eebfc71a8f99c7670adc8aea9f4f951))
* **web:** treat missing Telegram integration as empty state ([0cfd56c](https://github.com/usekaneo/kaneo/commit/0cfd56c44e77ea1d4bbe3e526e6b530437b3a5c3))
* **web:** use shared default locale in preferences labels ([592c2be](https://github.com/usekaneo/kaneo/commit/592c2bee260aaf272541200701f009936882a166))


### Features

* **api:** add activity/label updatedAt, indexes, and task number uniqueness ([c8b1163](https://github.com/usekaneo/kaneo/commit/c8b1163333594ec4be16c7fa14907bb763e81653))
* **api:** add Gitea integration REST API ([1778277](https://github.com/usekaneo/kaneo/commit/17782774d8f054e202d43d640136a80975c1d1d9))
* **api:** add Gitea integration schema for OpenAPI ([dcc7590](https://github.com/usekaneo/kaneo/commit/dcc75901c019e5181c55f25578250359b05ec8f5))
* **api:** add Gitea plugin with webhooks and sync helpers ([77e7836](https://github.com/usekaneo/kaneo/commit/77e7836fc23058888895d5e3268b99ceb67498b2))
* **api:** add task.updated_at column and migration ([440c3b9](https://github.com/usekaneo/kaneo/commit/440c3b98bbe50aca21f19c8227afa2ad2edd9fb2))
* **api:** create workflow rules for Gitea column migration ([9e5a6a1](https://github.com/usekaneo/kaneo/commit/9e5a6a1dec5e29eaabd00b9988a9f3cc261ed1ab))
* **api:** publish integration events for Telegram CRUD ([d99c8b5](https://github.com/usekaneo/kaneo/commit/d99c8b5795730295f2b318a85605031f905b06ee))
* **api:** register Gitea routes and webhook endpoint ([3c47c37](https://github.com/usekaneo/kaneo/commit/3c47c376e85a53b3f6a441c12821de70af8af662))
* **api:** sync task labels to Gitea ([8b6f932](https://github.com/usekaneo/kaneo/commit/8b6f932be2f8fb173bcd97713ac400677f4c8d03))
* **i18n:** add Gitea integration strings ([12cb1e8](https://github.com/usekaneo/kaneo/commit/12cb1e8545043eb30b19226ff846c54ad5d3872a))
* **integrations:** add project telegram integration ([63ff1a9](https://github.com/usekaneo/kaneo/commit/63ff1a925cfcbb1713edd55d8a193683f78bd4ee))
* **web:** add Gitea integration fetchers and query hooks ([78fbbef](https://github.com/usekaneo/kaneo/commit/78fbbef99f392ba99da04919c98b5dffb12c861a))
* **web:** add Gitea integration settings and workflow UI ([f1362d9](https://github.com/usekaneo/kaneo/commit/f1362d9fcda40ad27dd1e5ac53ac3f2308a279be))
* **web:** extend external links for Gitea sources and icons ([90badc7](https://github.com/usekaneo/kaneo/commit/90badc777e6209cdb1ad44566e4fee51d3ae6100))
* **web:** localize Gitea webhook controls and copy feedback ([7f90efa](https://github.com/usekaneo/kaneo/commit/7f90efa682615584394160a15fca51b00e6aa9df))
* **web:** render supportedLocales from resources.ts ([04a7bca](https://github.com/usekaneo/kaneo/commit/04a7bcad3431d43b14fa22f73d44ee1ccaaf3019))
## [2.4.4](https://github.com/usekaneo/kaneo/compare/v2.4.3...v2.4.4) (2026-03-30)


### Bug Fixes

* **api:** tighten webhook URL validation and dedupe Discord event handling ([5e834c2](https://github.com/usekaneo/kaneo/commit/5e834c23f4d4f563aa01dcf448bdd38407038727))
* **ci:** update Biome version to 2.4.8 and fix schema.json formatting ([e92c048](https://github.com/usekaneo/kaneo/commit/e92c048f8b5433f0d0fb4697677b47faea96bda6))
* **ci:** use GITHUB_TOKEN for dependabot fetch-metadata ([30631b9](https://github.com/usekaneo/kaneo/commit/30631b98a9f7d65aaa3a40ba94bc427a73f6d6f5))
* **discord:** hide webhook secrets and upsert integration ([27fe95a](https://github.com/usekaneo/kaneo/commit/27fe95aec5e239a5b44545d4afed38a470002d13))
* **discord:** preserve dirty integration form state ([12af824](https://github.com/usekaneo/kaneo/commit/12af824df68fd5554b81b667e9ba45e231e5d478))
* **discord:** redact webhook failures in logs ([ccc3f2e](https://github.com/usekaneo/kaneo/commit/ccc3f2e709fc02d65d308cca3d0bf73c38910ab7))
* **docs:** refine docs for outgoing webhooks ([c4680f7](https://github.com/usekaneo/kaneo/commit/c4680f75af3786f05845415ad44c441c1f8dcde3))
* guard generic webhook secret normalization ([95e166c](https://github.com/usekaneo/kaneo/commit/95e166ca9f3b544579f68841e7ae7838b5034c69))
* integration security and quality issues, add Discord/Slack docs ([3953cb4](https://github.com/usekaneo/kaneo/commit/3953cb4a32e3b361ab255b40bc4516befa5c921e))
* **integrations:** address review findings ([4189ece](https://github.com/usekaneo/kaneo/commit/4189ece3a4d3ce2b70919f9bdf7bac86a84468b1))
* **slack:** keep webhook URLs write-only ([0ad74ae](https://github.com/usekaneo/kaneo/commit/0ad74ae6bbb14b07a53485e4d47b7f27262ff459))
* **web:** normalize API base URLs ([d561804](https://github.com/usekaneo/kaneo/commit/d561804689e4ae392f73da379e2475cd53f7203d))


### Features

* add French locale (fr-FR) translations ([72a7cc1](https://github.com/usekaneo/kaneo/commit/72a7cc133873ae8d105d4cd1f5f6117b16732736))
* add Macedonian language option to preferences ([bd1f5b0](https://github.com/usekaneo/kaneo/commit/bd1f5b09276e19eb8d98c7600408d729d2e1eed9))
* **docs:** add outgoing webhooks ([d338bdd](https://github.com/usekaneo/kaneo/commit/d338bddddab7239e731ac67ba489df2f58d9f450))
* **integrations:** add Discord integration ([3488022](https://github.com/usekaneo/kaneo/commit/348802202b97f91269369471e81d1c547d5ce6bf))
* **integrations:** add generic outgoing webhooks ([89cce03](https://github.com/usekaneo/kaneo/commit/89cce03c0f141a7406683e843c4c639a2b017f84))
* **integrations:** add Slack integration ([9d69f8b](https://github.com/usekaneo/kaneo/commit/9d69f8b2d3b665477d1707d2537551bb378c001e))
* **webhooks:** persist generic webhook delivery health ([211280e](https://github.com/usekaneo/kaneo/commit/211280ea1e165dc01a41a49a71d6b63c6a1bf7e9))
## [2.4.3](https://github.com/usekaneo/kaneo/compare/v2.4.2...v2.4.3) (2026-03-29)


### Features

* add el-GR translation ([db47558](https://github.com/usekaneo/kaneo/commit/db475585a1df1f494567ee78eb4f84173c703df3))
* add el-GR translations ([eaeb7fb](https://github.com/usekaneo/kaneo/commit/eaeb7fbf4c218970375f76782fdea4c5c3abe42a))
* add greek language to schema ([f748efe](https://github.com/usekaneo/kaneo/commit/f748efe817e380c5ba8eb7c9c7b480d42c03049d))
* add Greek locale ([23187dd](https://github.com/usekaneo/kaneo/commit/23187dd58222eb1a67aa4af8360435b105b1cb82))
* add Greek locale file ([1584918](https://github.com/usekaneo/kaneo/commit/15849182879827a7324b073c2fd7bcb01285a4b6))
* Added support for el-GR ([6fb4429](https://github.com/usekaneo/kaneo/commit/6fb4429ee2f0c62df326edda9ad7efbff9d76f67))
* added support for el-GR language ([2f5ceb6](https://github.com/usekaneo/kaneo/commit/2f5ceb612582a10ab4ab470de1797d60f8c22cc5))
* **i18n:** add Macedonian (mk-MK) translation ([af2592b](https://github.com/usekaneo/kaneo/commit/af2592bfdbfef0c8304ba6df47d2cbd862512dc9))
## [2.4.2](https://github.com/usekaneo/kaneo/compare/v2.4.1...v2.4.2) (2026-03-29)


### Bug Fixes

* **api:** restore activity search for event data ([025d6fe](https://github.com/usekaneo/kaneo/commit/025d6fe065c330bdeb504abd59e82405f286cb3a))
* **auth:** localize invitation email subject ([4f3f10a](https://github.com/usekaneo/kaneo/commit/4f3f10a788bb1e8c96bd6ab5017f04d1b586e7b6))
* **deps:** patch security vulnerabilities in transitive dependencies ([b560b17](https://github.com/usekaneo/kaneo/commit/b560b17f70553806bc4da3d70562b052ded7b134))
* **docker:** copy i18n directory into web container build context ([187c72c](https://github.com/usekaneo/kaneo/commit/187c72cd03f58e1705bd62901827beef09dae7c7))
* **email:** localize auth sign-in emails ([e00a6e6](https://github.com/usekaneo/kaneo/commit/e00a6e633c865377b9dc3a44b54ceada7ce96352))
* resolve i18n review issues and improve UI components ([7a2172f](https://github.com/usekaneo/kaneo/commit/7a2172f0742b7a79dd3844081580bc4ed7b495f7))
* **ui:** touchAction on the sortable row style object is now conditional on isDragging ([#1098](https://github.com/usekaneo/kaneo/issues/1098)) ([fad643e](https://github.com/usekaneo/kaneo/commit/fad643e529ef38ccb3ba23a5a1b815723b0a1ded))
* **web:** correct backlog priority filter chip label ([c3bda60](https://github.com/usekaneo/kaneo/commit/c3bda6029985ea43242164b5f024db5cbf954878))
* **web:** invalidate session after locale updates ([2566f3e](https://github.com/usekaneo/kaneo/commit/2566f3eed6805b4d05c23c139be68c0677a5e3d0))
* **web:** make backlog due-date labels explicit ([5ea45a9](https://github.com/usekaneo/kaneo/commit/5ea45a91cb72b332d50bd31e1863fbb3aaf79229))
* **web:** preserve exact locale matching in resolver ([b9eae21](https://github.com/usekaneo/kaneo/commit/b9eae212cda8c7e9bf0a24de6242848053f6068c))
* **web:** refresh bulk priority labels on locale change ([966b75b](https://github.com/usekaneo/kaneo/commit/966b75b242ef08c9f3486d43c4453db823196b67))


### Features

* add initial configuration for Coderabbit integration ([#1099](https://github.com/usekaneo/kaneo/issues/1099)) ([2a4fa06](https://github.com/usekaneo/kaneo/commit/2a4fa066cdf7dc14bfd0522a749f9a4bb9ac14b5))
* **api:** add user locale and event_data columns for i18n ([270c5c7](https://github.com/usekaneo/kaneo/commit/270c5c719d6664256572ce16d74a25cd8f493d30))
* **api:** persist structured activity and notification events for i18n ([51c7a8c](https://github.com/usekaneo/kaneo/commit/51c7a8c56b456721236d49fd77a8b759eb430017))
* **api:** wire user locale into auth and API validation ([fff7d5e](https://github.com/usekaneo/kaneo/commit/fff7d5e7900036d135421ff59e3487f82227d63f))
* **email:** localize workspace invitation template ([f6bec30](https://github.com/usekaneo/kaneo/commit/f6bec303e27bc4cbe79422dcc40bddd2dfa120bf))
* **i18n:** add check, report, and schema maintenance scripts ([c2204ab](https://github.com/usekaneo/kaneo/commit/c2204ab2e643ef9d6bef770c40cdc726eddbaf1c))
* **i18n:** add English and German translation catalogs and schema ([8c27064](https://github.com/usekaneo/kaneo/commit/8c27064dd8308a627ac15abe4c535c53663f56d7))
* **web:** add i18next, locale hook, and Vite i18n integration ([8603385](https://github.com/usekaneo/kaneo/commit/860338571830f320884952a14d658a3b2b348571))
* **web:** internationalize components and task filter hooks ([06aee41](https://github.com/usekaneo/kaneo/commit/06aee41a0b2b3798edc39284da5e5ca055032d94))
* **web:** internationalize routes and notification types ([8132bab](https://github.com/usekaneo/kaneo/commit/8132bab6c4e3f385870c2defbc082d11b136041d))
* **web:** sync locale with auth session and account preferences ([d2339ff](https://github.com/usekaneo/kaneo/commit/d2339ffe2051730fe853ed36dcb9022f39ee293e))
## [2.4.2](https://github.com/usekaneo/kaneo/compare/v2.4.1...v2.4.2) (2026-03-29)


### Bug Fixes

* **api:** restore activity search for event data ([025d6fe](https://github.com/usekaneo/kaneo/commit/025d6fe065c330bdeb504abd59e82405f286cb3a))
* **auth:** localize invitation email subject ([4f3f10a](https://github.com/usekaneo/kaneo/commit/4f3f10a788bb1e8c96bd6ab5017f04d1b586e7b6))
* **deps:** patch security vulnerabilities in transitive dependencies ([b560b17](https://github.com/usekaneo/kaneo/commit/b560b17f70553806bc4da3d70562b052ded7b134))
* **email:** localize auth sign-in emails ([e00a6e6](https://github.com/usekaneo/kaneo/commit/e00a6e633c865377b9dc3a44b54ceada7ce96352))
* resolve i18n review issues and improve UI components ([7a2172f](https://github.com/usekaneo/kaneo/commit/7a2172f0742b7a79dd3844081580bc4ed7b495f7))
* **ui:** touchAction on the sortable row style object is now conditional on isDragging ([#1098](https://github.com/usekaneo/kaneo/issues/1098)) ([fad643e](https://github.com/usekaneo/kaneo/commit/fad643e529ef38ccb3ba23a5a1b815723b0a1ded))
* **web:** correct backlog priority filter chip label ([c3bda60](https://github.com/usekaneo/kaneo/commit/c3bda6029985ea43242164b5f024db5cbf954878))
* **web:** invalidate session after locale updates ([2566f3e](https://github.com/usekaneo/kaneo/commit/2566f3eed6805b4d05c23c139be68c0677a5e3d0))
* **web:** make backlog due-date labels explicit ([5ea45a9](https://github.com/usekaneo/kaneo/commit/5ea45a91cb72b332d50bd31e1863fbb3aaf79229))
* **web:** preserve exact locale matching in resolver ([b9eae21](https://github.com/usekaneo/kaneo/commit/b9eae212cda8c7e9bf0a24de6242848053f6068c))
* **web:** refresh bulk priority labels on locale change ([966b75b](https://github.com/usekaneo/kaneo/commit/966b75b242ef08c9f3486d43c4453db823196b67))


### Features

* add initial configuration for Coderabbit integration ([#1099](https://github.com/usekaneo/kaneo/issues/1099)) ([2a4fa06](https://github.com/usekaneo/kaneo/commit/2a4fa066cdf7dc14bfd0522a749f9a4bb9ac14b5))
* **api:** add user locale and event_data columns for i18n ([270c5c7](https://github.com/usekaneo/kaneo/commit/270c5c719d6664256572ce16d74a25cd8f493d30))
* **api:** persist structured activity and notification events for i18n ([51c7a8c](https://github.com/usekaneo/kaneo/commit/51c7a8c56b456721236d49fd77a8b759eb430017))
* **api:** wire user locale into auth and API validation ([fff7d5e](https://github.com/usekaneo/kaneo/commit/fff7d5e7900036d135421ff59e3487f82227d63f))
* **email:** localize workspace invitation template ([f6bec30](https://github.com/usekaneo/kaneo/commit/f6bec303e27bc4cbe79422dcc40bddd2dfa120bf))
* **i18n:** add check, report, and schema maintenance scripts ([c2204ab](https://github.com/usekaneo/kaneo/commit/c2204ab2e643ef9d6bef770c40cdc726eddbaf1c))
* **i18n:** add English and German translation catalogs and schema ([8c27064](https://github.com/usekaneo/kaneo/commit/8c27064dd8308a627ac15abe4c535c53663f56d7))
* **web:** add i18next, locale hook, and Vite i18n integration ([8603385](https://github.com/usekaneo/kaneo/commit/860338571830f320884952a14d658a3b2b348571))
* **web:** internationalize components and task filter hooks ([06aee41](https://github.com/usekaneo/kaneo/commit/06aee41a0b2b3798edc39284da5e5ca055032d94))
* **web:** internationalize routes and notification types ([8132bab](https://github.com/usekaneo/kaneo/commit/8132bab6c4e3f385870c2defbc082d11b136041d))
* **web:** sync locale with auth session and account preferences ([d2339ff](https://github.com/usekaneo/kaneo/commit/d2339ffe2051730fe853ed36dcb9022f39ee293e))
## [2.4.1](https://github.com/usekaneo/kaneo/compare/v2.4.0...v2.4.1) (2026-03-27)


### Bug Fixes

* validate task status and priority inputs across all API endpoints ([#1093](https://github.com/usekaneo/kaneo/issues/1093)) ([b3f6568](https://github.com/usekaneo/kaneo/commit/b3f656885961bf02835b6136f247d0a016db5a31))
* **web:** resolve Biome noArrayIndexKey lint in shortcuts, repo modal, and error display ([#1096](https://github.com/usekaneo/kaneo/issues/1096)) ([16eddd6](https://github.com/usekaneo/kaneo/commit/16eddd6d6974cb648b0312b40b38d21f9250ef80))


### Features

* **ui:** gantt chart resize dates ([#1095](https://github.com/usekaneo/kaneo/issues/1095)) ([7f7bd6b](https://github.com/usekaneo/kaneo/commit/7f7bd6bf9fd6bc6c9fa641aa3d80b3ebacfc0bd9))
* **ui:** refine ArchiveTasksModal layout and alignment ([#1091](https://github.com/usekaneo/kaneo/issues/1091)) ([528a982](https://github.com/usekaneo/kaneo/commit/528a982b7196b25299da2b51f5c3f564f1af0d97))
# [2.4.0](https://github.com/usekaneo/kaneo/compare/v2.3.16...v2.4.0) (2026-03-26)


### Bug Fixes

* enforce user ownership in notification endpoints ([#1089](https://github.com/usekaneo/kaneo/issues/1089)) ([16c28a9](https://github.com/usekaneo/kaneo/commit/16c28a92551a86c831419131d5499cad9e6ef762)), closes [#974](https://github.com/usekaneo/kaneo/issues/974)
* fix public project access after getTasks response shape change ([#1088](https://github.com/usekaneo/kaneo/issues/1088)) ([f17400e](https://github.com/usekaneo/kaneo/commit/f17400ed37d4676461c1cbcab308f4642b40a81e))
* improve task sidebar icon button styling ([ce6a53c](https://github.com/usekaneo/kaneo/commit/ce6a53cf69a01df8a6a09ef68429b32df66d24f9))
* mark optional Organization fields as nullable in OpenAPI spec ([#1090](https://github.com/usekaneo/kaneo/issues/1090)) ([a1755d3](https://github.com/usekaneo/kaneo/commit/a1755d3bcbbad4188338e63a02c0b6b0600f3989)), closes [#1087](https://github.com/usekaneo/kaneo/issues/1087)
* prevent start date after due date and improve activity messages ([61cb4d3](https://github.com/usekaneo/kaneo/commit/61cb4d3f67ceeb478d2014416045428425a88cea))
* resolve picomatch security vulnerabilities ([ee94d12](https://github.com/usekaneo/kaneo/commit/ee94d12d7664db9fc679c81ba8d7fcdb60d4b291))


### Features

* gantt view and task start date ([#1083](https://github.com/usekaneo/kaneo/issues/1083)) ([e1cc1ea](https://github.com/usekaneo/kaneo/commit/e1cc1ea30ecd124b9d25bf020e5a9a2d4c49a841))
## [2.3.16](https://github.com/usekaneo/kaneo/compare/v2.3.15...v2.3.16) (2026-03-24)


### Bug Fixes

* Subtasks default priority ([#1080](https://github.com/usekaneo/kaneo/issues/1080)) ([506fa55](https://github.com/usekaneo/kaneo/commit/506fa5531f05e2e36bdacf067c0ae26a4bdcc160))
* **ui:** make subtasks appear after creation without refresh ([#1084](https://github.com/usekaneo/kaneo/issues/1084)) ([a5daa49](https://github.com/usekaneo/kaneo/commit/a5daa49d2791544e8fafecc8c8caa85de25c71da))
## [2.3.15](https://github.com/usekaneo/kaneo/compare/v2.3.14...v2.3.15) (2026-03-23)


### Features

* add bulk assign labels, priority & deadlines ([bd5d7f4](https://github.com/usekaneo/kaneo/commit/bd5d7f463babcd501d204e9b23e32422458f0e49))
* add bulk assign labels, priority & deadlines ([37d1356](https://github.com/usekaneo/kaneo/commit/37d1356631fabd55db9f8e2d851f14442b43caa5))
## [2.3.14](https://github.com/usekaneo/kaneo/compare/v2.3.13...v2.3.14) (2026-03-23)


### Bug Fixes

* **api:** only apply task pagination when explicitly requested ([eed1c35](https://github.com/usekaneo/kaneo/commit/eed1c352e19cc2b17db7362bf99cc952d1b4be73)), closes [#1065](https://github.com/usekaneo/kaneo/issues/1065)


### Features

* **api,web:** add subtasks and task relations ([c73ef78](https://github.com/usekaneo/kaneo/commit/c73ef7821f054f8217568e8814c847c1c654bd76))
* **auth:** allow OIDC-only user registration ([5e8600e](https://github.com/usekaneo/kaneo/commit/5e8600e8f214d11dfa66e2e82117be5b88e23930))
* replace browser confirm with Archive modal ([9ed268f](https://github.com/usekaneo/kaneo/commit/9ed268f89ac29684e974757d5cf202031972fdf6))
* **web:** add relations to task detail, animated subtasks, and keyboard nav ([752bab0](https://github.com/usekaneo/kaneo/commit/752bab0277ba918eb8e4975e20d045bd8c8063b1))
* **web:** redesign subtasks UI with bulk actions ([9b059f3](https://github.com/usekaneo/kaneo/commit/9b059f39443971566d32ca49738bb2f84b37e079))
* **web:** refine breadcrumb and workspace switcher styling ([a2bcc9a](https://github.com/usekaneo/kaneo/commit/a2bcc9af27a118fce5701bc2daae0f82cca85554))
## [2.3.13](https://github.com/usekaneo/kaneo/compare/v2.3.12...v2.3.13) (2026-03-22)


### Bug Fixes

* **api:** only apply task pagination when explicitly requested ([500c609](https://github.com/usekaneo/kaneo/commit/500c609eda36e69bab6c2006a1d73b6851817286)), closes [#1065](https://github.com/usekaneo/kaneo/issues/1065)


### Features

* **web:** refine breadcrumb and workspace switcher styling ([bd52ce2](https://github.com/usekaneo/kaneo/commit/bd52ce27ae393cd6b9b89f42f7deb0176f9b5003))
## [2.3.12](https://github.com/usekaneo/kaneo/compare/v2.3.11...v2.3.12) (2026-03-21)


### Bug Fixes

* **api,web:** fix kanban position persistence and task numbering ([59d5771](https://github.com/usekaneo/kaneo/commit/59d57711bd7921684130e583da30de796db5417d))
* **api:** consolidate migrations into single 0015 without duplicate asset table ([ebb9b67](https://github.com/usekaneo/kaneo/commit/ebb9b67de41305cc2bd8a832a453a479b841c991))
* project key input limit ([a330444](https://github.com/usekaneo/kaneo/commit/a3304440ef035735588819b09ee5a4a9df4832d3))


### Features

* **api,web:** add global search with short-id support ([c74987d](https://github.com/usekaneo/kaneo/commit/c74987d9800263deb466837ac8beb8fd3231be75))
* **api:** add pagination, bulk ops, comments, members, and project archival ([af22fd2](https://github.com/usekaneo/kaneo/commit/af22fd257fd5e3cdcfd31e62045be350d4c2e399))
* better label color support ([d8f5c55](https://github.com/usekaneo/kaneo/commit/d8f5c5542f2d10786328dcbcf5bf1880265475ef)), closes [#1058](https://github.com/usekaneo/kaneo/issues/1058)
* **web:** add sorting controls to board, backlog, and list views ([a9c46e9](https://github.com/usekaneo/kaneo/commit/a9c46e9b6c3f8f32343727024fd32fcb58468eb1))
## [2.3.11](https://github.com/usekaneo/kaneo/compare/v2.3.10...v2.3.11) (2026-03-14)


### Features

* **api,web:** fix task access and editor link handling ([710d175](https://github.com/usekaneo/kaneo/commit/710d17517f181f5d19c1e32b9190680d7b0f8c69))
## [2.3.10](https://github.com/usekaneo/kaneo/compare/v2.3.9...v2.3.10) (2026-03-14)


### Bug Fixes

* due date calendar width ([63e4bb5](https://github.com/usekaneo/kaneo/commit/63e4bb5c5fef4f31df0d821a3397c15abef79f2a))
* mistake with regex ([28b2221](https://github.com/usekaneo/kaneo/commit/28b222129d3fadea9d4a09335e55969a04d35785))
* **web:** preserve text color on autofilled inputs in dark theme ([8fb0b9e](https://github.com/usekaneo/kaneo/commit/8fb0b9e38e82425913090123972ffea2ab1e68d1))
## [2.3.9](https://github.com/usekaneo/kaneo/compare/v2.3.8...v2.3.9) (2026-03-13)


### Bug Fixes

* file upload with umlauts ([07718d7](https://github.com/usekaneo/kaneo/commit/07718d7843bb6ca1a47c1ef33fed500a15e5e8b2))


### Features

* enhance file upload functionality for attachments ([c76af9d](https://github.com/usekaneo/kaneo/commit/c76af9dcd712a688a0c8d49fab7cd3c8cff47c2f))
## [2.3.8](https://github.com/usekaneo/kaneo/compare/v2.3.7...v2.3.8) (2026-03-11)


### Features

* add image upload functionality to task descriptions and comments ([33f6940](https://github.com/usekaneo/kaneo/commit/33f69409f00da4341d1c3ad849ae865d2606c7c5))
## [2.3.7](https://github.com/usekaneo/kaneo/compare/v2.3.6...v2.3.7) (2026-03-11)


### Bug Fixes

* update actions/checkout version to v6 in workflow files ([d26728b](https://github.com/usekaneo/kaneo/commit/d26728b4be7ca63bfbc0b33cf34c8403af900e71))
## [2.3.6](https://github.com/usekaneo/kaneo/compare/v2.3.4...v2.3.6) (2026-03-11)


### Bug Fixes

* update auto-merge conditions and change merge strategy to squash ([51ede69](https://github.com/usekaneo/kaneo/commit/51ede69004cf47382e029e4005f1f01807aa5c2b))
* update better-auth and tiptap dependencies to latest versions ([9583146](https://github.com/usekaneo/kaneo/commit/9583146a38eb042b33df504e9f3456f68876fdf0))
* update packageManager version to pnpm@10.32.1 ([c25c33d](https://github.com/usekaneo/kaneo/commit/c25c33db791de63153c79474d6f496dfb3da64ec))


### Features

* redesign task details page ([d2bebe8](https://github.com/usekaneo/kaneo/commit/d2bebe8a6827c0d8f3512bd9fd7fb67ad1a55943))
## [2.3.4](https://github.com/usekaneo/kaneo/compare/v2.3.3...v2.3.4) (2026-03-05)


### Bug Fixes

* update API server URL to use HTTPS ([88e869f](https://github.com/usekaneo/kaneo/commit/88e869f66fd50fd15f9087549d74d0858abbe675))
* update organization paths to include auth prefix ([e7b2a42](https://github.com/usekaneo/kaneo/commit/e7b2a424afd860ebce473566ef6f69d7a9c7d07b))
* update task assignee retrieval to use user table ([f8fed51](https://github.com/usekaneo/kaneo/commit/f8fed517b8beb578e8fab6e8a200342d7358865b))


### Features

* add operation summary generation for OpenAPI specs ([14939d2](https://github.com/usekaneo/kaneo/commit/14939d291968d4e65c5b44a74037366609aabcc5))
* openapi spec + migrations ([50b0ae5](https://github.com/usekaneo/kaneo/commit/50b0ae54a047d915cd15dc06c97e28aa7ac3ca9f))
## [2.3.3](https://github.com/usekaneo/kaneo/compare/v2.3.2...v2.3.3) (2026-03-04)


### Bug Fixes

* api keys couldn't be created ([04c8f8f](https://github.com/usekaneo/kaneo/commit/04c8f8f7ab65c78bbd6c2ab15a608b481eef223a))
## [2.3.2](https://github.com/usekaneo/kaneo/compare/v2.3.1...v2.3.2) (2026-03-03)


### Bug Fixes

* consolidate imports from better-auth/api ([3e7e2c6](https://github.com/usekaneo/kaneo/commit/3e7e2c6f1d4be274a044b8c0594fdfa27df463c7))
* update auth logic and add apiKey dependency ([22c9c2a](https://github.com/usekaneo/kaneo/commit/22c9c2af760a7097e35960c6bd4c8c4e48963abc))
## [2.3.1](https://github.com/usekaneo/kaneo/compare/v2.3.0...v2.3.1) (2026-03-02)


### Bug Fixes

* favicon ([3dbe1b9](https://github.com/usekaneo/kaneo/commit/3dbe1b9171a198070edf643757c5cb992b99d5a3))
* **types:** align client models and add reliable web typecheck command ([e9ea473](https://github.com/usekaneo/kaneo/commit/e9ea4731984bcbe7e94634aa1b48fbbc83bebe6a))


### Features

* add Plausible analytics scripts for tracking ([736791a](https://github.com/usekaneo/kaneo/commit/736791a04cee3aa43f0c0dbcccce58db7e0bafe5))
* implement FadeIn component for smooth animations in landing pages ([9fcaaac](https://github.com/usekaneo/kaneo/commit/9fcaaac58c5d0424a30ef87fbf057e4a548e3d6b))
* **settings:** refresh settings sidebars and project/workspace UX ([3424436](https://github.com/usekaneo/kaneo/commit/3424436ad3d1137df90c2895ff5d9e628be6c192))
* **tasks:** improve bulk selection, column actions, and task detail popovers ([6723296](https://github.com/usekaneo/kaneo/commit/6723296ab59c1be365fbbb51326ad3e44c97e4b3))
# [2.3.0](https://github.com/usekaneo/kaneo/compare/v2.2.1...v2.3.0) (2026-02-25)


### Features

* add app preview in landing page ([0ea7d88](https://github.com/usekaneo/kaneo/commit/0ea7d88f6040e280a617f1ac2fde58574918cc3a))
* improve styles for filters ([615d5dd](https://github.com/usekaneo/kaneo/commit/615d5dd2efda9618766acd267c3684aac727a1ce))
* **web:** implement board search functionality and integrate with task filters ([aa5d86a](https://github.com/usekaneo/kaneo/commit/aa5d86ac18e007bd3827bdf98791a057cd6450b6))
* **web:** persist board filters and polish linear-style filter chips ([e3f7f9d](https://github.com/usekaneo/kaneo/commit/e3f7f9df98a7fc0aa11fc93b78fcb38f5d3fbf20))
* **web:** polish kanban and backlog interactions ([041cd87](https://github.com/usekaneo/kaneo/commit/041cd87eb74bf860e5c0aed2811aafbc845e79b5))
* **web:** revamp dashboard shell navigation and header controls ([d87a779](https://github.com/usekaneo/kaneo/commit/d87a77946143206d8578d06e2f2dab79c5930790))



## [2.2.1](https://github.com/usekaneo/kaneo/compare/v2.2.0...v2.2.1) (2026-02-16)


### Bug Fixes

* apps/web/Dockerfile to reduce vulnerabilities ([c1b5731](https://github.com/usekaneo/kaneo/commit/c1b57312cff8d09ef23d7aee95d315d582b6af35))



# [2.2.0](https://github.com/usekaneo/kaneo/compare/v2.1.24...v2.2.0) (2026-02-09)


### Features

* **columns:** add column management ([189236c](https://github.com/usekaneo/kaneo/commit/189236cd1976899cdf9f8a3316981eb034e191b7))
* enhance task status management with new utility functions and improved status update logic ([48a90bf](https://github.com/usekaneo/kaneo/commit/48a90bf3465d23fa66361e346e20f1b1a7e9d4cb))
* update getColumnIcon to accept isFinal parameter and apply changes across components ([277832d](https://github.com/usekaneo/kaneo/commit/277832d766d326889d69ea0e01978d6ca6da093c))



## [2.1.24](https://github.com/usekaneo/kaneo/compare/v2.1.23...v2.1.24) (2026-02-05)


### Bug Fixes

* **tasks:** fix task deletion ([d86f864](https://github.com/usekaneo/kaneo/commit/d86f8641215fbad4391622f82225e21b3e29b068))



## [2.1.23](https://github.com/usekaneo/kaneo/compare/v2.1.21...v2.1.23) (2026-01-17)



## [2.1.21](https://github.com/usekaneo/kaneo/compare/v2.1.20...v2.1.21) (2026-01-12)


### Features

* integrate input-otp component for OTP verification ([70a80dd](https://github.com/usekaneo/kaneo/commit/70a80dd91007591e8f5d0b0f8b9328f0f39fbfe6))



## [2.1.20](https://github.com/usekaneo/kaneo/compare/v2.1.19...v2.1.20) (2026-01-11)


### Bug Fixes

* correct wording in OTP email template for improved clarity ([7bfa5a1](https://github.com/usekaneo/kaneo/commit/7bfa5a12322face817c3cb221162ef264080b135))



## [2.1.19](https://github.com/usekaneo/kaneo/compare/v2.1.18...v2.1.19) (2026-01-11)


### Bug Fixes

* update OTP email text for clarity ([cec7566](https://github.com/usekaneo/kaneo/commit/cec75665bc10004bad019b986750c629014b8c71))



## [2.1.18](https://github.com/usekaneo/kaneo/compare/v2.1.17...v2.1.18) (2026-01-11)


### Features

* enhance task due date management with clearing functionality and UI improvements ([a9155cb](https://github.com/usekaneo/kaneo/commit/a9155cbefc406ed37b0b53e1695af3bbd3e6b802))



## [2.1.17](https://github.com/usekaneo/kaneo/compare/v2.1.16...v2.1.17) (2026-01-11)



## [2.1.16](https://github.com/usekaneo/kaneo/compare/v2.1.15...v2.1.16) (2026-01-11)


### Features

* add admin authentication and enhance task comment event with user details ([6e08df9](https://github.com/usekaneo/kaneo/commit/6e08df906b05253f3a1aec625c50b1bb96364170))



## [2.1.15](https://github.com/usekaneo/kaneo/compare/v2.1.14...v2.1.15) (2026-01-11)


### Features

* implement task comment creation event handling and integrate with GitHub plugin ([089421d](https://github.com/usekaneo/kaneo/commit/089421dce8c94a4317e676ace08a69f8cca71339))
* integrate Bun for documentation generation and add OpenAPI fetching scripts ([0389477](https://github.com/usekaneo/kaneo/commit/03894779efc0235a75743424d9580cc5a1742f68))



## [2.1.14](https://github.com/usekaneo/kaneo/compare/v2.1.13...v2.1.14) (2026-01-10)


### Features

* enhance GitHub integration documentation ([fc4ccbf](https://github.com/usekaneo/kaneo/commit/fc4ccbfbd7ffed0ada6799201cd4dfbb29a34faf))
* improve invites for smtp off users ([0282c0d](https://github.com/usekaneo/kaneo/commit/0282c0d4db519236c01d2ed50e6e08727e605677))



## [2.1.13](https://github.com/usekaneo/kaneo/compare/v2.1.12...v2.1.13) (2026-01-09)


### Features

* enhance touch interactions and improve drag-and-drop responsiveness in Kanban board ([cefc5b4](https://github.com/usekaneo/kaneo/commit/cefc5b49e7656b24681844bd34d9bc5d1d7e79a6))



## [2.1.12](https://github.com/usekaneo/kaneo/compare/v2.1.11...v2.1.12) (2026-01-09)


### Features

* add keyboard shortcuts help dialog and enhance task selection with focus management ([25bd9ee](https://github.com/usekaneo/kaneo/commit/25bd9eed3152c2cf62c5aa42ae20f98891462116))



## [2.1.11](https://github.com/usekaneo/kaneo/compare/v2.1.10...v2.1.11) (2026-01-08)


### Features

* add bulk select toolbar on backlog and list view ([9fc2cad](https://github.com/usekaneo/kaneo/commit/9fc2cad875e2cee928ad2fb3e7f97d2dfa959024))
* enhance GitHub issue and pull request handling matching ([660e026](https://github.com/usekaneo/kaneo/commit/660e0265dbc95b044da4c6fd87f0e54515161c0e))
* improve github integration, fix invitation bugs, move to otp, email templates improvements ([ab26286](https://github.com/usekaneo/kaneo/commit/ab2628688e07cfa37973fcbfa4cae508966585a9))



## [2.1.10](https://github.com/usekaneo/kaneo/compare/v2.1.9...v2.1.10) (2026-01-05)



## [2.1.9](https://github.com/usekaneo/kaneo/compare/v2.1.8...v2.1.9) (2026-01-04)



## [2.1.8](https://github.com/usekaneo/kaneo/compare/v2.1.7...v2.1.8) (2026-01-04)


### Features

* enhance auto-merge workflow for Dependabot PRs ([a321a4b](https://github.com/usekaneo/kaneo/commit/a321a4bdc266b53fdef691deebce1ec678ad8768))
* enhance email invitation handling with SMTP configuration check ([51b8c60](https://github.com/usekaneo/kaneo/commit/51b8c6019263372ff503f87097bdeac1efae81be))
* implement bulk selection and actions for tasks with a new toolbar and menu ([be1f90a](https://github.com/usekaneo/kaneo/commit/be1f90a60eb04a5f0857c3330e7ca02e60c9a8db))
* update issue import functionality to include closed issues and handle pull request links ([bdb030e](https://github.com/usekaneo/kaneo/commit/bdb030e1325e67b156d69394f656baecba66279a))



## [2.1.7](https://github.com/usekaneo/kaneo/compare/v2.1.6...v2.1.7) (2026-01-04)


### Bug Fixes

* adjust docs link ([fc93297](https://github.com/usekaneo/kaneo/commit/fc93297f4d5f307b207d86b254453879f5a72d50))


### Features

* add external link and integration tables with relations ([d8d6f4c](https://github.com/usekaneo/kaneo/commit/d8d6f4c8bf38d014c42430a1cb0886ad5948aec9))
* add task title and description change events to GitHub integration ([60ecffd](https://github.com/usekaneo/kaneo/commit/60ecffdc93ac9ed7fc82bd9023f521c256adcb42))
* enhance activity schema and GitHub integration ([c2a557e](https://github.com/usekaneo/kaneo/commit/c2a557ef07bc0515c4bfdcb34d1916ff8347bd21))
* enhance GitHub issue import functionality ([f270e73](https://github.com/usekaneo/kaneo/commit/f270e7319776bea78cb089ee08042861fe1423d7))
* improve repository listing for GitHub installations ([b7f31bd](https://github.com/usekaneo/kaneo/commit/b7f31bd0ac7773b68dd8267c1825d19560d84f91))
* integrate pull request display in task row with hover card support ([d89494d](https://github.com/usekaneo/kaneo/commit/d89494d90c6aede11814e519e67ea55cebd98c76))



## [2.1.6](https://github.com/usekaneo/kaneo/compare/v2.1.5...v2.1.6) (2025-12-20)


### Features

* add access control to API endpoints ([977d49e](https://github.com/usekaneo/kaneo/commit/977d49e7ce7c366a89641970332a3da3ed714183))
* add GitHub webhook handling and workspace access validation ([49f416f](https://github.com/usekaneo/kaneo/commit/49f416fd646671ba663aedddaa47b2a7b6dbd98f))



## [2.1.5](https://github.com/usekaneo/kaneo/compare/v2.1.4...v2.1.5) (2025-12-16)



## [2.1.4](https://github.com/usekaneo/kaneo/compare/v2.1.1...v2.1.4) (2025-12-15)


### Bug Fixes

* **auth:** improve OAuth scopes handling and update redirect URI in documentation ([92a345b](https://github.com/usekaneo/kaneo/commit/92a345bd3752cdddd70d8f77557e35a24b072707))


### Features

* **api:** enhance workspace access validation with API key support ([c18391a](https://github.com/usekaneo/kaneo/commit/c18391a81f844b5cf49f1d309d7185aca462f157))
* **docs:** create initial DocsPage component with redirect to core documentation ([4aa1f02](https://github.com/usekaneo/kaneo/commit/4aa1f02961005bce82ed2e53eb842fa33125c436))



## [2.1.1](https://github.com/usekaneo/kaneo/compare/v2.0.9...v2.1.1) (2025-12-13)


### Bug Fixes

* **api:** improve query validation and update API URL structure ([fe306d8](https://github.com/usekaneo/kaneo/commit/fe306d831ed67b2c1f5106410a3c5b4325adb62b))
* prevent create task modal from closing on outside click ([2d76d12](https://github.com/usekaneo/kaneo/commit/2d76d12c5234eddd873f50457048faa72bf8a4d2))
* resolve linter issues ([62592fe](https://github.com/usekaneo/kaneo/commit/62592fe8f349394570289fb180e5b7bc04ce6ac6))


### Features

* add DISABLE_GUEST_ACCESS environment variable ([c7b14a2](https://github.com/usekaneo/kaneo/commit/c7b14a2748a4d11a10051a1b42db5534d5ff85c1))
* **api:** add Discord and guest access sign-in options to config schema ([00194a8](https://github.com/usekaneo/kaneo/commit/00194a88e4e9d0a2563400cc778ece000a50004e))
* **api:** add event subscriptions for task activity tracking ([f921402](https://github.com/usekaneo/kaneo/commit/f921402f21e4349228d8152092b1d149f9b34dcd))
* **api:** add OpenAPI endpoint and documentation handler ([7123a45](https://github.com/usekaneo/kaneo/commit/7123a45da0143db905cfcd434cb2c41c2e0cb408))
* **api:** add shared response schemas for OpenAPI documentation ([4b949b0](https://github.com/usekaneo/kaneo/commit/4b949b06cbdc37d0e82b1d3fdb57423880260415))
* **api:** add updatedAt field to githubIntegrationSchema ([2b4054c](https://github.com/usekaneo/kaneo/commit/2b4054c15ecb8e8bdaeba9edd16c942cfc0a23a1))
* **api:** add workspace access validation utility ([aeabf4c](https://github.com/usekaneo/kaneo/commit/aeabf4cd5f5fb021e0ffe4179e953e78590086a0))
* **api:** enhance deleteComment function to return deleted comment ([84ed5fc](https://github.com/usekaneo/kaneo/commit/84ed5fc832924468443fead790ee0bda09c59f18))
* **api:** enhance event subscriptions for task and workspace notifications ([04429bb](https://github.com/usekaneo/kaneo/commit/04429bbeb812a2bbe7758b824bfae3c391e48d0e))
* **api:** implement updateTimeEntry functionality in time-entry API ([4b92c46](https://github.com/usekaneo/kaneo/commit/4b92c46e399fdf2943ad67614e9d6a24bc758860))
* **api:** implement workspace access middleware for project routes ([81c3c85](https://github.com/usekaneo/kaneo/commit/81c3c859e8ff25635e30d9eed3447243448ddcca))
* **api:** improve API key verification and error handling ([88bf481](https://github.com/usekaneo/kaneo/commit/88bf481e7e606746982f58879ebb74b6258766d9))
* **api:** remove optional description field from label schema ([0d4d2da](https://github.com/usekaneo/kaneo/commit/0d4d2da319992bee453b6e3901bd24df314a2f28))
* **api:** replace v.any() with proper type schemas in all routes ([1618e6f](https://github.com/usekaneo/kaneo/commit/1618e6f8b326fb29cf047441c4b64e30d9da7d73))
* **api:** update OpenAPI schema and dependencies ([303db4b](https://github.com/usekaneo/kaneo/commit/303db4b07da76cb12e6f382d0ce4b725059012d2))
* **api:** validate task creation data and update notification content ([c31d94f](https://github.com/usekaneo/kaneo/commit/c31d94f9cfaac4942d582fbf34c9abf2a1846c8c))
* **auth:** add api key authentication middleware ([9cccb87](https://github.com/usekaneo/kaneo/commit/9cccb87d3406af68c9336b5f57e656bdbb86bb01))
* **auth:** add custom OAuth provider support ([a566702](https://github.com/usekaneo/kaneo/commit/a566702f6e89023332a59164c4914a7a66536c84))
* **auth:** add support for custom OAuth/OIDC provider integration ([2eb0cdc](https://github.com/usekaneo/kaneo/commit/2eb0cdc8922ab2b5eaff4114d347220332de62d2))
* **auth:** add support for custom OAuth/OIDC provider integration ([3f043b5](https://github.com/usekaneo/kaneo/commit/3f043b56c5ed26c032b432960161c17bb6d2e678))
* **database:** update workspace slug handling ([8ac2e0a](https://github.com/usekaneo/kaneo/commit/8ac2e0a8b6d53781ade95b26e0a40710baaba7a1))
* **database:** update workspace slug handling ([1aab22f](https://github.com/usekaneo/kaneo/commit/1aab22fa564ddd96b80af5d479f1f935baa3cba2))
* **db:** add api key migration ([496ced2](https://github.com/usekaneo/kaneo/commit/496ced27734dd661cd51d51204a334df2cbf2079))
* **db:** add api key relations ([5c54bb5](https://github.com/usekaneo/kaneo/commit/5c54bb5438f127aa986a31c6fb7b1033514077d7))
* **db:** add api key table schema ([3e4e7bf](https://github.com/usekaneo/kaneo/commit/3e4e7bf44d8299f9415e544f8e797fb3ec9d3810))
* **db:** export api key table from database ([75594bf](https://github.com/usekaneo/kaneo/commit/75594bfb8e65f92ce11571a679f66485a7290af6))
* **docs:** add API overview page with endpoint cards ([3763f7e](https://github.com/usekaneo/kaneo/commit/3763f7e0b1afa9ba0f661ccae03c0250d0afb817))
* **docs:** add API page client component ([ab6b5e0](https://github.com/usekaneo/kaneo/commit/ab6b5e097f8bf2c02d00d06cecbaaf8ad1e3a1b3))
* **docs:** add API page server component ([9d9ff47](https://github.com/usekaneo/kaneo/commit/9d9ff47e036dbfd7688057f2a32af5d5b2777fcb))
* **docs:** add authentication guide and update API documentation ([8a0cf44](https://github.com/usekaneo/kaneo/commit/8a0cf446ccaed57f32b5f87c301b346a2fa5c352))
* **docs:** add documentation generation script ([2cc6fcf](https://github.com/usekaneo/kaneo/commit/2cc6fcf53c311e007ca63b007d2d070823020df3))
* **docs:** add OpenAPI API route ([3fa272d](https://github.com/usekaneo/kaneo/commit/3fa272d0b4a073043c392123974cbb409f410b49))
* **docs:** add OpenAPI parsing utilities ([3ab6cd7](https://github.com/usekaneo/kaneo/commit/3ab6cd7954578ad930136e23285b7c5a1644e430))
* **docs:** add OpenAPI specification file ([e6acefe](https://github.com/usekaneo/kaneo/commit/e6acefe12275f684123ed4dc870951cf758b16e6))
* **docs:** add redirects from old documentation paths ([753452f](https://github.com/usekaneo/kaneo/commit/753452f68f95a4dfd373dfc865bf7be18c77aec8))
* **docs:** configure docs generator to group endpoints by domain ([5efa841](https://github.com/usekaneo/kaneo/commit/5efa8418a5c08d66fe4e22f1ff80171e5f2216a3))
* **docs:** update docs layout navigation ([fad9207](https://github.com/usekaneo/kaneo/commit/fad9207a0808e6f7ec3bdf37c45eed082b52eef8))
* **docs:** update docs page for API routes ([78cdfb3](https://github.com/usekaneo/kaneo/commit/78cdfb34caba5ffc2b6a36546a1f7e1e59b5a555))
* **docs:** update internal links to new documentation structure ([6a532b7](https://github.com/usekaneo/kaneo/commit/6a532b7c627fb0be132938e0ada4d1976fdc942c))
* **docs:** update source configuration for new structure ([09e65d9](https://github.com/usekaneo/kaneo/commit/09e65d90355e13a15d8f91b7fd235d0a20bb7b2b))
* **web:** add api key created modal component ([b803bc9](https://github.com/usekaneo/kaneo/commit/b803bc90fd2825529f3a89f91eea671d6ae8de69))
* **web:** add api key query hook ([fbc0785](https://github.com/usekaneo/kaneo/commit/fbc07853c9a44cf792e7e435c52d7b8d965280a5))
* **web:** add api key table component ([4cd2f90](https://github.com/usekaneo/kaneo/commit/4cd2f903753135f2dc6530d9fc00087ad6ec3167))
* **web:** add api key types ([3bd855f](https://github.com/usekaneo/kaneo/commit/3bd855f9700704c0be70b080358cc1ee8af9661a))
* **web:** add create api key dialog component ([2a1ea9b](https://github.com/usekaneo/kaneo/commit/2a1ea9b38253c7123e939f216086265149925f9d))
* **web:** add create api key mutation hook ([b1ba33d](https://github.com/usekaneo/kaneo/commit/b1ba33df43daed8ce8598e4b6a5bb25a8714ecfd))
* **web:** add delete api key mutation hook ([af4f4a5](https://github.com/usekaneo/kaneo/commit/af4f4a5dc29cd4cf1f496d7916c5dc1a8f948569))
* **web:** add developer settings page ([94316fa](https://github.com/usekaneo/kaneo/commit/94316fa1f8677f528f7d1772f0da1055f6c76394))
* **web:** add developer tab to account settings ([2190eab](https://github.com/usekaneo/kaneo/commit/2190eabb51a0a4e17e22352b9e3bc43d56916aab))



## [2.0.9](https://github.com/usekaneo/kaneo/compare/v2.0.8...v2.0.9) (2025-12-10)


### Bug Fixes

* prevent create task modal from closing on outside click ([436fb7b](https://github.com/usekaneo/kaneo/commit/436fb7bbe760a0b9083d90c9246e1a8c5aa885f5))


### Features

* add DISABLE_GUEST_ACCESS environment variable ([9641324](https://github.com/usekaneo/kaneo/commit/9641324edd11a799fca03d366fe8c3a8b0de920b))
* **database:** update session and workspace schemas ([ef98dd3](https://github.com/usekaneo/kaneo/commit/ef98dd3455a0578b61f2ae00d5c5f38b73919949))



## [2.0.8](https://github.com/usekaneo/kaneo/compare/v2.0.7...v2.0.8) (2025-12-09)


### Features

* **auth:** add support for custom OAuth/OIDC provider integration ([f67a6f6](https://github.com/usekaneo/kaneo/commit/f67a6f66b61612e13e065e2798a899a9dae44ecc))



## [2.0.7](https://github.com/usekaneo/kaneo/compare/v2.0.6...v2.0.7) (2025-12-08)


### Features

* **migration:** update invitation table to add created_at column with default value handling ([527ae8a](https://github.com/usekaneo/kaneo/commit/527ae8a21f6800ce094f1de799ab0868ce4a746a))



## [2.0.6](https://github.com/usekaneo/kaneo/compare/v2.0.5...v2.0.6) (2025-12-08)


### Features

* **auth:** enhance base URL handling and trusted origins ([07fa1b6](https://github.com/usekaneo/kaneo/commit/07fa1b69b20db59a425d357537effca6e75e1b6c))



## [2.0.5](https://github.com/usekaneo/kaneo/compare/v2.0.4...v2.0.5) (2025-12-07)


### Features

* **migration:** rename active_workspace_id to active_organization_id ([b89ae83](https://github.com/usekaneo/kaneo/commit/b89ae8325ffe353bd4ff8d5b938244c7ba651726))



## [2.0.4](https://github.com/usekaneo/kaneo/compare/v2.0.3...v2.0.4) (2025-12-05)


### Bug Fixes

* Fix Status not updating when moved in the grid ([#638](https://github.com/usekaneo/kaneo/issues/638)) ([b51af1a](https://github.com/usekaneo/kaneo/commit/b51af1a5f4c8e2acff08c8e8bf371d7b4e4d9b75))
* standardize title separator from ⎯ to — across metadata and layout files ([c9979ad](https://github.com/usekaneo/kaneo/commit/c9979adb09453f24f7b1f0a6f5b60e4c56733c69))


### Features

* add ThemeToggleDropdown component and integrate into AppSidebar ([#652](https://github.com/usekaneo/kaneo/issues/652)) ([9200a75](https://github.com/usekaneo/kaneo/commit/9200a759a7a920126cddc3f43aa845d5fdc54658))
* **email:** Add option to enable RequireTLS ([#630](https://github.com/usekaneo/kaneo/issues/630)) ([c99f6bc](https://github.com/usekaneo/kaneo/commit/c99f6bc5bc678fb48d5368f526d17270d2258b0d))



## [2.0.3](https://github.com/usekaneo/kaneo/compare/v2.0.2...v2.0.3) (2025-11-05)



## [2.0.2](https://github.com/usekaneo/kaneo/compare/v2.0.1...v2.0.2) (2025-11-02)


### Bug Fixes

* update footer link to point directly to the documentation root ([8e9674f](https://github.com/usekaneo/kaneo/commit/8e9674f1a79f5e36a66cfed4724e1a321e564acf))


### Features

* add version display to app sidebar and expose app version globally ([87778ae](https://github.com/usekaneo/kaneo/commit/87778aed616190d2136fcc09cb939995c7cd61e7))



## [2.0.1](https://github.com/usekaneo/kaneo/compare/v2.0.0...v2.0.1) (2025-11-02)


### Bug Fixes

* ensure API URL structure is consistent by handling trailing '/api' in base URL ([6a03fa4](https://github.com/usekaneo/kaneo/commit/6a03fa4d78e931a7ef2327348aa238f594a8deec))


### Features

* adds removing of a team member ([ca96157](https://github.com/usekaneo/kaneo/commit/ca9615710dd0de7203fd7112d4502527ce67501a))
* enhance authentication configuration for cross-subdomain support and update API client paths ([343f374](https://github.com/usekaneo/kaneo/commit/343f37462cb078844c55a761cca55092a3a0708b))
* refactor API routing to use separate Hono instance and update client API URL structure ([20bbf00](https://github.com/usekaneo/kaneo/commit/20bbf003036fcd3aa0d8c5521f9e6cf9fbdcc54a))



# [2.0.0](https://github.com/usekaneo/kaneo/compare/v1.2.4...v2.0.0) (2025-10-23)


### Bug Fixes

* preserve formatting when copy/pasting in new task modal ([#432](https://github.com/usekaneo/kaneo/issues/432)) ([#481](https://github.com/usekaneo/kaneo/issues/481)) ([b105d43](https://github.com/usekaneo/kaneo/commit/b105d43d0d90f434c573999c9961fd5ac9b8e8e9))


### Features

* better auth integration ([#466](https://github.com/usekaneo/kaneo/issues/466)) ([91bb9c2](https://github.com/usekaneo/kaneo/commit/91bb9c2a86c25fddb34fff7b589f9684d945b184))
* implement onboarding flow and update routing ([#469](https://github.com/usekaneo/kaneo/issues/469)) ([6f7057b](https://github.com/usekaneo/kaneo/commit/6f7057b13fa8817f1a00b3a05cd008de913ff6b7))



## [2.0.1-beta.2](https://github.com/usekaneo/kaneo/compare/v1.2.4...v2.0.1-beta.2) (2025-10-01)


### Bug Fixes

* adjust button margin in sign-up form for improved layout ([dc8db99](https://github.com/usekaneo/kaneo/commit/dc8db99dd1485bf84c426bfd04f18b3f96eb6e7e))
* merge conflicts, route gen ([4838df3](https://github.com/usekaneo/kaneo/commit/4838df30f5d51e7c9374f277bce9dd1b39f3b1c4))
* preserve formatting when copy/pasting in new task modal ([#432](https://github.com/usekaneo/kaneo/issues/432)) ([#481](https://github.com/usekaneo/kaneo/issues/481)) ([b105d43](https://github.com/usekaneo/kaneo/commit/b105d43d0d90f434c573999c9961fd5ac9b8e8e9))
* update active item styles in navigation components and adjust sign-in callback URL ([c73e8e4](https://github.com/usekaneo/kaneo/commit/c73e8e44c3793727abc4e17128b11166b038af61))
* update email placeholder in sign-in and sign-up forms for consistency ([564f6a6](https://github.com/usekaneo/kaneo/commit/564f6a6bf0a5d5ace9ce8537ae5343e8ce36bac9))


### Features

* add animation classes and keyframes for enhanced UI transitions in CSS ([220cce7](https://github.com/usekaneo/kaneo/commit/220cce723f4c5ec043cd04093b60ec7f8e074dc5))
* add environment configuration and update service definitions for local development ([273a7ce](https://github.com/usekaneo/kaneo/commit/273a7ce02757cc7dd817a5e8e66a17db4deab33e))
* add GitHub sign-in support with environment variable configuration ([0fc8528](https://github.com/usekaneo/kaneo/commit/0fc8528cb762b442042f909733a3e61a68df0718))
* add health check endpoint and update Dockerfile health check command ([aedc019](https://github.com/usekaneo/kaneo/commit/aedc0193ae76d66e6207f421ed19d2a6c40f1dfd))
* add label filtering support to task management, enhancing task visibility and organization ([880572f](https://github.com/usekaneo/kaneo/commit/880572fd1e62366ac01d4fad8e1b2d5b7ad13a21))
* add task management popovers for assignee, due date, priority, and status ([87ae386](https://github.com/usekaneo/kaneo/commit/87ae3866d36be88a4668f81c78af7b2bfdea969e))
* add team and team_member tables, enhance invitation and label tables with new columns, and implement foreign key constraints ([3e174e6](https://github.com/usekaneo/kaneo/commit/3e174e63ba8a6cb2ed31de89fe1f96d8b6e54006))
* add user avatar component and enhance sidebar navigation with workspace switcher ([3b3b9a3](https://github.com/usekaneo/kaneo/commit/3b3b9a3524019a201428d030d6a051a5cbd6932c))
* better auth integration ([#466](https://github.com/usekaneo/kaneo/issues/466)) ([91bb9c2](https://github.com/usekaneo/kaneo/commit/91bb9c2a86c25fddb34fff7b589f9684d945b184))
* enhance email invitation functionality ([cd84548](https://github.com/usekaneo/kaneo/commit/cd84548de2fc68d66eb1356ef331affe762abfb9))
* enhance sidebar navigation with search functionality and UI improvements ([9dacada](https://github.com/usekaneo/kaneo/commit/9dacada90616ce2527011cf984918b0e9cc57bff))
* enhance task labels functionality with deduplication and improved filtering in the board view ([ea8cca3](https://github.com/usekaneo/kaneo/commit/ea8cca302e91fe7153367ff48adb3235cb682b6e))
* enhance task management with activity tracking and updates for assignee, priority, and status ([f37b975](https://github.com/usekaneo/kaneo/commit/f37b975bf2219a22d2199f1d7d59a791590f75e3))
* implement due date update functionality in task management with associated activity tracking ([e177a46](https://github.com/usekaneo/kaneo/commit/e177a4650440ccaa1d7b18697e17027714780849))
* implement magic link authentication and email sending functionality ([90139d7](https://github.com/usekaneo/kaneo/commit/90139d7ce4f88e3113dacea4735d7062b7114fb6))
* implement onboarding flow and update routing ([#469](https://github.com/usekaneo/kaneo/issues/469)) ([6f7057b](https://github.com/usekaneo/kaneo/commit/6f7057b13fa8817f1a00b3a05cd008de913ff6b7))
* implement password hashing and verification using bcrypt in authentication ([17cce57](https://github.com/usekaneo/kaneo/commit/17cce57dbcba0465f447b5b8c927b892c084c36e))
* implement team and label management features in the database schema and API ([6864ec9](https://github.com/usekaneo/kaneo/commit/6864ec9e3e06dedf69e9585d0089975fe228538a))
* initial docs refactor ([cfd92f4](https://github.com/usekaneo/kaneo/commit/cfd92f401b35ed0414242fdf9ba2a9439916af60))
* initial task details page ([43fe59a](https://github.com/usekaneo/kaneo/commit/43fe59ad88bfba18912e0d3979cded8f5b2cb74f))
* integrate rich text editing for task description and title with improved state management ([27d0413](https://github.com/usekaneo/kaneo/commit/27d041337e753c191da10f77080b08ee245e15de))
* migrates web to use auth client organization methods ([5ec4d28](https://github.com/usekaneo/kaneo/commit/5ec4d283b52d1fd8a1eb2645b768898158aee0f6))
* refactor create task modal with new task description editor and enhanced label management ([7649ac0](https://github.com/usekaneo/kaneo/commit/7649ac06e87835e2bbbe84031c0ca274bee96558))
* update dependencies and enhance documentation layout with new features section ([bd6d9b9](https://github.com/usekaneo/kaneo/commit/bd6d9b9b8dffbb7a22079f6530d062fb91445ae3))
* update environment configuration and integrate dotenv-mono for improved variable management ([ffcb482](https://github.com/usekaneo/kaneo/commit/ffcb4821256cef46e34c39ab94c678700175bd1d))



## [1.2.4](https://github.com/usekaneo/kaneo/compare/v1.2.3...v1.2.4) (2025-08-17)


### Bug Fixes

* **#389:** added archived to the calculation of "solved" tickets ([#437](https://github.com/usekaneo/kaneo/issues/437)) ([4e21e6a](https://github.com/usekaneo/kaneo/commit/4e21e6a6740a32044b85c8e7a720d9240d048ee7)), closes [#389](https://github.com/usekaneo/kaneo/issues/389)
* reorder imports in task-activities and task-comment components for consistency ([3267efe](https://github.com/usekaneo/kaneo/commit/3267efe56178413a53497c2f47be745839e4ef62))


### Features

* **#383:** add rich text editor for comments ([#435](https://github.com/usekaneo/kaneo/issues/435)) ([9787e0b](https://github.com/usekaneo/kaneo/commit/9787e0b075f68286fa2e2d81d516f84ee877d084)), closes [#383](https://github.com/usekaneo/kaneo/issues/383)
* **391:** add "archive" and "planned" to the context menu of cards ([#436](https://github.com/usekaneo/kaneo/issues/436)) ([48f4a03](https://github.com/usekaneo/kaneo/commit/48f4a03a3a4b13fa069890100ba3af82958bc92a))
* enhance metadata and sitemap for improved SEO and user experience ([472ff23](https://github.com/usekaneo/kaneo/commit/472ff231656025c0b7bb939c8c01bff0bd2b63be))
* replace loading indicators with a new LoadingSkeleton component for improved UI consistency ([d4c7069](https://github.com/usekaneo/kaneo/commit/d4c7069da5eff244c46fb8fc7b81c144fb0e80ba))



## [1.2.3](https://github.com/usekaneo/kaneo/compare/v1.2.2...v1.2.3) (2025-08-06)



## [1.2.2](https://github.com/usekaneo/kaneo/compare/v1.2.1...v1.2.2) (2025-08-06)


### Bug Fixes

* update default API URL to localhost and add ASCII art logo in main entry file ([0b44b86](https://github.com/usekaneo/kaneo/commit/0b44b86ef067059eb8c73c362e7ee4d7fcbf12dc))


### Features

* implement GitHub issue handling for task status and priority changes ([6d7fe20](https://github.com/usekaneo/kaneo/commit/6d7fe200f3ae1fa73149d36e6a87f179f8e8796d))



## [1.2.1](https://github.com/usekaneo/kaneo/compare/v1.2.0...v1.2.1) (2025-08-05)


### Features

* add delete task confirmation dialog to task card and task info components ([0fa817f](https://github.com/usekaneo/kaneo/commit/0fa817f972407cb4e6669b964dec052950eebbf1))
* enhance task description formatting and skip GitHub issue creation for related tasks ([63cca0a](https://github.com/usekaneo/kaneo/commit/63cca0ac5160724e09065fef95bdd6ad723cde3d))



# [1.2.0](https://github.com/usekaneo/kaneo/compare/v1.1.9...v1.2.0) (2025-08-01)


### Bug Fixes

* resolve delete project dialog bug ([#419](https://github.com/usekaneo/kaneo/issues/419)) ([9d11864](https://github.com/usekaneo/kaneo/commit/9d1186494d725cb585cd35d435800fcb2b628529))



## [1.1.9](https://github.com/usekaneo/kaneo/compare/v1.1.8...v1.1.9) (2025-07-30)



## [1.1.8](https://github.com/usekaneo/kaneo/compare/v1.1.7...v1.1.8) (2025-07-22)


### Features

* add croner for scheduled tasks and implement demo user setup ([cfcfd60](https://github.com/usekaneo/kaneo/commit/cfcfd6034589ee3caa57ea42234260f82d7afa34))



## [1.1.7](https://github.com/usekaneo/kaneo/compare/v1.1.6...v1.1.7) (2025-07-22)


### Features

* enable demo mode in layout and dashboard components ([c6cd1fc](https://github.com/usekaneo/kaneo/commit/c6cd1fc3719276c66693cc0c8457816257299778))



## [1.1.6](https://github.com/usekaneo/kaneo/compare/v1.1.5...v1.1.6) (2025-07-22)



## [1.1.5](https://github.com/usekaneo/kaneo/compare/v1.1.4...v1.1.5) (2025-07-21)


### Bug Fixes

* port number in documentation ([#375](https://github.com/usekaneo/kaneo/issues/375)) ([b1e9814](https://github.com/usekaneo/kaneo/commit/b1e981468667e6ad03276c2172ea23393d40c2c5))



## [1.1.4](https://github.com/usekaneo/kaneo/compare/v1.1.0...v1.1.4) (2025-07-10)


### Bug Fixes

* update task detail modal to display assignee name ([2884c78](https://github.com/usekaneo/kaneo/commit/2884c78c77edfbef23ce01eef8fef8d153208bda))


### Features

* implement GitHub issues import functionality ([ef1bb63](https://github.com/usekaneo/kaneo/commit/ef1bb636dc1876d0d4d2108f732efc98d2568bec))
* implement global search functionality ([f840ec7](https://github.com/usekaneo/kaneo/commit/f840ec79269dbdaed53d1be6755e011e485c040f))
* implement task detail modal and enhance task interaction ([eb3abcc](https://github.com/usekaneo/kaneo/commit/eb3abccdb8a98afcc6be7063e85451e8364cdbf0))



# [1.1.0](https://github.com/usekaneo/kaneo/compare/v1.0.9...v1.1.0) (2025-07-06)


### Bug Fixes

* update task assignee handling and improve task display ([e23f230](https://github.com/usekaneo/kaneo/commit/e23f230891ee7e24fff1e16a67d36a7fda73a585))


### Features

* enhance task retrieval and display with assignee details ([18c5cb2](https://github.com/usekaneo/kaneo/commit/18c5cb28685cb930be93eccb9387208d7ef3969b))



## [1.0.9](https://github.com/usekaneo/kaneo/compare/v1.0.2...v1.0.9) (2025-07-05)


### Bug Fixes

* update Quick Start link in README to point to documentation ([cfed1cc](https://github.com/usekaneo/kaneo/commit/cfed1ccc312081dc6fc405479e091ae0c4ec8d21))


### Features

* add configuration endpoint and integrate config handling in sign-up flow ([700266d](https://github.com/usekaneo/kaneo/commit/700266d237c5787ee6991344380a5afbdd4dd9c7))
* add documentation links to home layout with icons ([6c1a350](https://github.com/usekaneo/kaneo/commit/6c1a350fe3885ce4b1e37a4684f2f0b44cc69166))
* add theme selection options to command palette ([1683937](https://github.com/usekaneo/kaneo/commit/1683937da3329d5cd97e0c6d64054dfde433a798))
* update footer with operational status link and visual indicator ([4018f13](https://github.com/usekaneo/kaneo/commit/4018f13d884d4f4e9c7e5b03f4e552bc522ddad6))
* update layout configuration and metadata ([8bd9407](https://github.com/usekaneo/kaneo/commit/8bd9407d18c5d57285e837636ad88a6ddb34f55f))



## [1.0.2](https://github.com/usekaneo/kaneo/compare/v1.0.1...v1.0.2) (2025-06-22)



## [1.0.1](https://github.com/usekaneo/kaneo/compare/v1.0.0...v1.0.1) (2025-06-22)


### Features

* GitHub integration ([#323](https://github.com/usekaneo/kaneo/issues/323)) ([1457e37](https://github.com/usekaneo/kaneo/commit/1457e37b10cd2c5a3a8b6fda0782172b9e72c035))



# [1.0.0](https://github.com/usekaneo/kaneo/compare/v0.4.0...v1.0.0) (2025-06-20)


### Bug Fixes

* adjust metadata title template for Kaneo documentation ([4e696ab](https://github.com/usekaneo/kaneo/commit/4e696ab7ba233a5a1359de0ae7389a44d37b2c3d))
* simplify metadata default title for Kaneo documentation ([3c24b09](https://github.com/usekaneo/kaneo/commit/3c24b09898e3cbd91198ce831d21baaaf1d32ad1))
* update metadata template for Kaneo project ([020e383](https://github.com/usekaneo/kaneo/commit/020e383918c1881ddb9cb68dfbdcf51fe6621d12))
* update metadata title template for Kaneo documentation ([2fe6196](https://github.com/usekaneo/kaneo/commit/2fe6196545b3c1ecec912e880e9367d95e868767))


### Features

* add manifest and icons for Kaneo project management platform ([fe2d19d](https://github.com/usekaneo/kaneo/commit/fe2d19d937bc4e96aa42b9badc0554e0b4918c59))
* **board:** add CreateTaskModal for task creation functionality ([2bec2d0](https://github.com/usekaneo/kaneo/commit/2bec2d0e92d9f16408f551d08eb87582977ff213))
* comments ui proposal ([#262](https://github.com/usekaneo/kaneo/issues/262)) ([741bbc4](https://github.com/usekaneo/kaneo/commit/741bbc41f617c2cb521e7937c66ab60202713793))
* enhance project settings form with unsaved changes warning ([36854d9](https://github.com/usekaneo/kaneo/commit/36854d926069b48b62f896c48d0dbace849d830c))
* **hero:** update hero component to promote Kaneo Cloud with new icon and link ([23935fb](https://github.com/usekaneo/kaneo/commit/23935fb45b53b03f9e02bb3753677ab1eb96ebed))
* **index.html:** add Plausible Analytics script for cloud.kaneo.app domain ([4edabaf](https://github.com/usekaneo/kaneo/commit/4edabafad7387e8d7ec384548fe10c2af2303ca2))
* migrate from SQLite to PostgreSQL ([#315](https://github.com/usekaneo/kaneo/issues/315)) ([ee540d4](https://github.com/usekaneo/kaneo/commit/ee540d407ce8708874dc6d5694c80eb5e40107b4))
* update documentation with cloud version promotion ([add275c](https://github.com/usekaneo/kaneo/commit/add275cbbd85eeb57186d58f8f7ada2363ea1a61))



# [0.4.0](https://github.com/usekaneo/kaneo/compare/v0.3.0...v0.4.0) (2025-05-10)


### Bug Fixes

* add out directory to ignored files in biome.json ([5607363](https://github.com/usekaneo/kaneo/commit/5607363dc2e015f2ca7ce248964102aa3191532a))
* correct Open Graph image URL to use the proper domain path ([c2f928f](https://github.com/usekaneo/kaneo/commit/c2f928f308116211d06b332cae6cf944d7ac1e46))
* edit project slug max length ([#137](https://github.com/usekaneo/kaneo/issues/137)) ([e8b1c3c](https://github.com/usekaneo/kaneo/commit/e8b1c3cd6071a76d30430564531a2d8461397c7e))
* ensure tables are created only if they do not already exist ([36e6cde](https://github.com/usekaneo/kaneo/commit/36e6cde6128576c9b0caae4c23ab3cb2bcc8bcde))
* fix workspace setting sidebar icon ([#157](https://github.com/usekaneo/kaneo/issues/157)) ([a64f7ba](https://github.com/usekaneo/kaneo/commit/a64f7bad43b208469c5043e9b078ce36667a19b4))
* fixed the saving of the indent of the description of the task ([#219](https://github.com/usekaneo/kaneo/issues/219)) ([201d7ee](https://github.com/usekaneo/kaneo/commit/201d7eefac0203bb221794c481c8921a4ae85756))
* project is highlighted when backlog is active ([#131](https://github.com/usekaneo/kaneo/issues/131)) ([b7daaa3](https://github.com/usekaneo/kaneo/commit/b7daaa37a07a1e88d1d744cd118bd1718db946a6))
* remove title from SVG in Open Graph component and add lint ignore comment ([8db20af](https://github.com/usekaneo/kaneo/commit/8db20af507f909f81135eb964466de5b1d1d67eb))
* remove unnecessary logging of slug in metadata generation ([ad5c814](https://github.com/usekaneo/kaneo/commit/ad5c8147e46a0db785a680dc56b97c2bda874fcc))
* reorder import statements in layout file for consistency ([13c092f](https://github.com/usekaneo/kaneo/commit/13c092f9e9e50e56b0561c5c698afdf711ac6394))
* streamline Open Graph image URL by consolidating domain path ([662ba97](https://github.com/usekaneo/kaneo/commit/662ba97530f9f5887db484331c8ecd694625b3c8))
* update API URL handling in client initialization ([c01daad](https://github.com/usekaneo/kaneo/commit/c01daadfafcd488ed9e7eaf2ad8f52c3360277d2))
* update base path and image URL for Open Graph metadata in documentation ([f4ae3c1](https://github.com/usekaneo/kaneo/commit/f4ae3c1616306ef1b253ee0fc7cdbb89bf1c4d39))
* update environment variable handling and Dockerfile comments ([6222ad6](https://github.com/usekaneo/kaneo/commit/6222ad6080cf768364830814c522c69c207dc0c5))
* update font file paths for Open Graph image generation ([08c13b8](https://github.com/usekaneo/kaneo/commit/08c13b8b383aa56a9adac5ad04dd21931d00ee14))
* update Open Graph image generation and enhance metadata logging ([18c821d](https://github.com/usekaneo/kaneo/commit/18c821dceae414d13bb849578668fd6d9c30e624))
* update Open Graph image URL to include full domain path ([e9498f1](https://github.com/usekaneo/kaneo/commit/e9498f12ea2379e4b51419e2375773e094300889))
* update Open Graph image URL to use the correct GitHub Pages domain ([0645f15](https://github.com/usekaneo/kaneo/commit/0645f15b0aa5fb96412022b18050d0f71f6c9043))
* update port forwarding configuration in documentation and deployment files ([4e01f98](https://github.com/usekaneo/kaneo/commit/4e01f98e1a102b07725f15a05f858270734430d0))
* update registration environment variable and improve error handling ([e5c5b0f](https://github.com/usekaneo/kaneo/commit/e5c5b0f07c97a2e8b4864e3d03cacae163c2796a))
* update site name in Open Graph metadata and enhance layout for image generation ([cdd243c](https://github.com/usekaneo/kaneo/commit/cdd243c58694e7f6f8e8e4bfcd2fcd81bf25dab1))
* update site name in Open Graph metadata and enhance layout for image generation ([bfbad94](https://github.com/usekaneo/kaneo/commit/bfbad94613b74a933a5fce882e8ef3179b1fd4de))


### Features

* add "Edit on GitHub" link to documentation pages ([2acb149](https://github.com/usekaneo/kaneo/commit/2acb14937c617f2cc50f32c669fc11173591df9a))
* add documentation site with Next.js and Fumadocs ([#163](https://github.com/usekaneo/kaneo/issues/163)) ([014c9cf](https://github.com/usekaneo/kaneo/commit/014c9cfa27e25047daa1a0f24fb391ce78dcd457))
* add Icon component for Open Graph image generation and update metadata structure ([75ece2a](https://github.com/usekaneo/kaneo/commit/75ece2a037a472d15b4c9813bb1a0d6e5d6acab8))
* add Inter font files and integrate them into Open Graph image generation ([469dba2](https://github.com/usekaneo/kaneo/commit/469dba2666d90b618d93c3fa975eb4c7580bffa2))
* add issue and pull request templates for better contribution guidelines ([bb47fda](https://github.com/usekaneo/kaneo/commit/bb47fdaf1a6a1dc22f6407ff466020803e1681b4))
* add label management functionality ([6ea9406](https://github.com/usekaneo/kaneo/commit/6ea9406f5577f5a68a90f7d23f22c4b02a8d1555))
* add Plausible analytics script to layout components ([30a066c](https://github.com/usekaneo/kaneo/commit/30a066c90260b97deb0378d1fae81bc8f1b83a8b))
* add registration control feature ([#134](https://github.com/usekaneo/kaneo/issues/134)) ([5b86636](https://github.com/usekaneo/kaneo/commit/5b866368581f6559a10ce951acaad5a7345f02ea))
* add sitemap generation and Open Graph image support ([0ba4fb0](https://github.com/usekaneo/kaneo/commit/0ba4fb09eca1f852375d5882a645366ef69111c6))
* add sorting functionality to task filters ([#217](https://github.com/usekaneo/kaneo/issues/217)) ([3d3d4a8](https://github.com/usekaneo/kaneo/commit/3d3d4a87853e566f2d3c4530e7c2264beb74d40f))
* add task import/export functionality ([f8612a3](https://github.com/usekaneo/kaneo/commit/f8612a3261e2a7a3a6f2613ed5ef939569d8a035))
* delete a task option [#122](https://github.com/usekaneo/kaneo/issues/122) ([#216](https://github.com/usekaneo/kaneo/issues/216)) ([86bacb6](https://github.com/usekaneo/kaneo/commit/86bacb69cffc669eae2b3816fdb809fcee5d4c74))
* disable create project and workspace buttons ([#133](https://github.com/usekaneo/kaneo/issues/133)) ([89e2d66](https://github.com/usekaneo/kaneo/commit/89e2d66165c77fc39500ff8a533431c956cda469))
* enhance CreateTaskModal with improved layout and scrolling ([#183](https://github.com/usekaneo/kaneo/issues/183)) ([452b80b](https://github.com/usekaneo/kaneo/commit/452b80b19c4002d91ebf3c19bec8103c2defc0d0))
* enhance homepage metadata for SEO and social sharing ([622367e](https://github.com/usekaneo/kaneo/commit/622367ec2eb7c3aed6ddbee07be7be923f0b42c4))
* enhance project settings with task data and project icon ([62084a8](https://github.com/usekaneo/kaneo/commit/62084a8d6950006e32178fb7175ae6c81634f2b0))
* implement time tracking feature for tasks ([#172](https://github.com/usekaneo/kaneo/issues/172)) ([2c4e4ca](https://github.com/usekaneo/kaneo/commit/2c4e4ca921cc49f99ed691da98dca076ebc450f5))
* integrate project data fetching in task edit page ([a5d64c2](https://github.com/usekaneo/kaneo/commit/a5d64c27a81b750f8134ad195a97a35ebaef9f58))
* migrate to node.js ([#138](https://github.com/usekaneo/kaneo/issues/138)) ([d099533](https://github.com/usekaneo/kaneo/commit/d099533809a50c8611c5594952706541cf92091d))
* **notification:** implement notification system ([#270](https://github.com/usekaneo/kaneo/issues/270)) ([3907fb2](https://github.com/usekaneo/kaneo/commit/3907fb23042e8654a6e799167098a81873f661ab))
* right click card/row context menu ([#238](https://github.com/usekaneo/kaneo/issues/238)) ([0754ae1](https://github.com/usekaneo/kaneo/commit/0754ae1e77eb2ffab22dc5fd478c1b248090b671))
* set base path for documentation site to "/kaneo" ([88661a0](https://github.com/usekaneo/kaneo/commit/88661a0bfae81b19fd157fc9d5b8871efd04b7de))
* update Hero component link to roadmap and add live roadmap ([c62925f](https://github.com/usekaneo/kaneo/commit/c62925f28ae32b572ae2414dafbfcc6542dcaddb))
* workspace details update and delete feature added ([#119](https://github.com/usekaneo/kaneo/issues/119)) ([44af5ff](https://github.com/usekaneo/kaneo/commit/44af5ff2be063700efbcfb758ba6ca01b2084a77))



# [0.3.0](https://github.com/usekaneo/kaneo/compare/v0.2.0...v0.3.0) (2025-03-26)


### Bug Fixes

* accessibility issues with workspace picker ([78cf89e](https://github.com/usekaneo/kaneo/commit/78cf89ec44054ce2d2ed049c436ad1c3864a5291))
* improves bakclog task row popover styles ([cfd7ea8](https://github.com/usekaneo/kaneo/commit/cfd7ea88f2797511ca6afda3b8e2f0508b99bec7))


### Features

* adds acl's and removing of team members ([43963a0](https://github.com/usekaneo/kaneo/commit/43963a0f70ab10d32606b4adac3d646d3836ba74))
* adds archiving of tasks ([4bfb3eb](https://github.com/usekaneo/kaneo/commit/4bfb3eb5dd8a9228d534ecba9ded5796a8e74357))
* adds backlog ([5fb541c](https://github.com/usekaneo/kaneo/commit/5fb541c81501b08255c227aaacee9694e8160fcd))



# [0.2.0](https://github.com/usekaneo/kaneo/compare/v0.1.0...v0.2.0) (2025-03-24)


### Bug Fixes

* adapting list view on mobile drag ([217ceab](https://github.com/usekaneo/kaneo/commit/217ceabaa2c40ecad76d571fa450d6adfa89ae19))
* adding clear all filters buttons, making responsive ([e5d04dc](https://github.com/usekaneo/kaneo/commit/e5d04dc5f5cfcf5e5ea6b9a41f7e1848bfcdb87b))
* adding loading spinner on task edit page ([d61ffe6](https://github.com/usekaneo/kaneo/commit/d61ffe6d6b7170f01a94e24c4eeacc41800a4c38))
* clear input fields when closing create task dialog ([#115](https://github.com/usekaneo/kaneo/issues/115)) ([731687e](https://github.com/usekaneo/kaneo/commit/731687ecd6b2dee74f8ff1805a39639dd18719b5))
* Clear input fields when closing dialogs ([#89](https://github.com/usekaneo/kaneo/issues/89)) ([1578c0e](https://github.com/usekaneo/kaneo/commit/1578c0ecb6c675c6162f8421ce48d18bd69d9ab0))
* deciding scure of cookie based on request protocol ([3980cdf](https://github.com/usekaneo/kaneo/commit/3980cdf125e5b21c0ab1e3c67bad52084f7f4f25))
* disabling inviting already invited users ([7d13439](https://github.com/usekaneo/kaneo/commit/7d134396c1f2b5d57a0e3fc594ba35fbb65067d5))
* fixing desktop layout for task edition ([07ec9bf](https://github.com/usekaneo/kaneo/commit/07ec9bf183dbcb60b0a3517ea0ed9882f247ae2d))
* fixing desktop styles for task edit ([cb40454](https://github.com/usekaneo/kaneo/commit/cb404545e3a6df3ec86f9b6492f68c4541382c9a))
* force field validation errors ([#109](https://github.com/usekaneo/kaneo/issues/109)) ([654a185](https://github.com/usekaneo/kaneo/commit/654a185c9dbe6f679327c634af016af50e947efa))
* loading tasks initially ([91174ca](https://github.com/usekaneo/kaneo/commit/91174cac3f1a92d0a563926a9bd00b79ce0d902c))
* lowering elysia version to 1.2.15 ([30de754](https://github.com/usekaneo/kaneo/commit/30de7540d940738f12c8fb50cc3debbe4a0410a3))
* making alert have only 12 rem height ([df9a798](https://github.com/usekaneo/kaneo/commit/df9a798c5ccf73d39d9969c8045a398a4b7daf22))
* making board skeletons full width ([77fd7b4](https://github.com/usekaneo/kaneo/commit/77fd7b44cff4df4e261a90c52fd8f8f2c4ce9a85))
* making columns grow as much space as they have ([a8a3540](https://github.com/usekaneo/kaneo/commit/a8a35406d9dcee3b2d44c20637b4778a5fd8768a))
* making demo email unique ([cd42ed2](https://github.com/usekaneo/kaneo/commit/cd42ed2fb0b0e776eec119637cfdcfe45aca2b67))
* making new session for demo user and updating data purge for every hour ([4db1105](https://github.com/usekaneo/kaneo/commit/4db1105681b8fdb6134641456ea60adb87b4402c))
* making tooltip work on mobile ([66ff3f3](https://github.com/usekaneo/kaneo/commit/66ff3f3b3b457bcfe7fc05e00feaf8bb962f5036))
* not returning from middleware ([b71f4c6](https://github.com/usekaneo/kaneo/commit/b71f4c6adb3bfbb2f0d06beee9bdfe14a6510526))
* removing console log ([19bfbc6](https://github.com/usekaneo/kaneo/commit/19bfbc6d31792597b9ef4db61d422445b81dcec7))
* removing fixed height on alert ([cacec48](https://github.com/usekaneo/kaneo/commit/cacec486995634e416c2b8867f13e526c2facacf))
* removing un-setting to workspace and projects when going to settings ([d4b8e5a](https://github.com/usekaneo/kaneo/commit/d4b8e5aa7858958fca15ddc5a24ef7385e099e90))
* renewing sessions on demo mode ([2118510](https://github.com/usekaneo/kaneo/commit/2118510f61f6aa336213387217210ec9e0e530a7))
* returing padding to board ([56d3086](https://github.com/usekaneo/kaneo/commit/56d30860f6ad42acebad16de81099be27eefcc69))
* session expired wasn't getting recreated on demo ([30c0fbb](https://github.com/usekaneo/kaneo/commit/30c0fbbc25fdbf7d4913107098f90a4734efb3ab))
* setting demo sessions to 15m ([d45129c](https://github.com/usekaneo/kaneo/commit/d45129c13c6a190099bfe2ef2cf97fe1a7d21187))
* settings page had workspace selection screen ([6dfa90f](https://github.com/usekaneo/kaneo/commit/6dfa90f483e78906dee087efd44b043b91321504))
* showing empty state for workspaces ([cdf8b11](https://github.com/usekaneo/kaneo/commit/cdf8b119092c77bdd6627ad775ecc291bbcf8e88))


### Features

* add alert for demo page ([#85](https://github.com/usekaneo/kaneo/issues/85)) ([eeca442](https://github.com/usekaneo/kaneo/commit/eeca442f0ef7d9462c83b387ddc20622850ee8aa))
* adding board filters ([8c55b37](https://github.com/usekaneo/kaneo/commit/8c55b37a5ce1d77a926955f18409e92b91e12e93))
* adding demo setup ([#83](https://github.com/usekaneo/kaneo/issues/83)) ([2ff307a](https://github.com/usekaneo/kaneo/commit/2ff307a0b60d6c453dd2806cfb3d42c49f6e2489))
* adding dynamic titles ([6c7d5f2](https://github.com/usekaneo/kaneo/commit/6c7d5f2a09015c190b90714c72a5e669c10d8067))
* adding option to update/remove projects ([8478ab0](https://github.com/usekaneo/kaneo/commit/8478ab06d8daf6487227c7723073129fbf177881))
* adding position of tickets in columns ([93556e7](https://github.com/usekaneo/kaneo/commit/93556e7f71aefe202ee68366004d4b10ab4bcb31))
* adding rich text editor in create task modal ([0f18b94](https://github.com/usekaneo/kaneo/commit/0f18b94f8e6dcecc63ceb6d200c17aa467953782))
* adding seo support ([029a3af](https://github.com/usekaneo/kaneo/commit/029a3afabb660b3b087a8090eccd254caed9f5fa))
* adding toast component ([2bb4f1c](https://github.com/usekaneo/kaneo/commit/2bb4f1cf8f54000030014336a41300a4a84cb359))
* **deployment:** add Helm chart and improve container security ([#116](https://github.com/usekaneo/kaneo/issues/116)) ([139fb51](https://github.com/usekaneo/kaneo/commit/139fb51c5e7e64d5b7bb646f4dfefa5ca954008a)), closes [#80](https://github.com/usekaneo/kaneo/issues/80) [#80](https://github.com/usekaneo/kaneo/issues/80)
* **frontend:** :sparkles: adds cmd+k ([70e0407](https://github.com/usekaneo/kaneo/commit/70e0407c0cc0ad6347e8c6019f7c37904c3224a9))
* improved seo ([15b3747](https://github.com/usekaneo/kaneo/commit/15b37477f5a4e13c02505d6102b1a8a1eb0d387f))
* list view ([5f15ebc](https://github.com/usekaneo/kaneo/commit/5f15ebc1ca8c75d8480beaaa8dfadbdef8548d60))
* making tasks editable ([#97](https://github.com/usekaneo/kaneo/issues/97)) ([67448aa](https://github.com/usekaneo/kaneo/commit/67448aa550e1f14a3f5b80019bab707a11e509bb))
* migrating from rabbit mq to node's event emitter ([1a3fe5f](https://github.com/usekaneo/kaneo/commit/1a3fe5f7c410fd64d263338b772a121c7c0f6158))
* moving from websockets and using polling ([da4dc1a](https://github.com/usekaneo/kaneo/commit/da4dc1a9ab0db3d9094d55af365147a5f9e32b65))
* updating user info popup ([ed75a39](https://github.com/usekaneo/kaneo/commit/ed75a391ac4a4ee6b214f97655e864b218ac5a8a))



# 0.1.0 (2025-02-22)


### Bug Fixes

* :bug: fixing deleted workspaces being cached ([624b206](https://github.com/usekaneo/kaneo/commit/624b20676fedf1b1a5871f916a5c1d5c38a5d2cb))
* :bug: fixing overflowing workspace names ([0c2ab27](https://github.com/usekaneo/kaneo/commit/0c2ab2705d82c86ace8b4919c59d7773b63e989d))
* :bug: fixing route generation for vite ([73ddd6d](https://github.com/usekaneo/kaneo/commit/73ddd6d0138e9223921cbefdd727b2fa61408be0))
* :bug: remove unused import ([fa639e1](https://github.com/usekaneo/kaneo/commit/fa639e15e1c847d4ac89b7925fb2606b6e5900a4))
* :construction_worker: fixing build on pipeline ([767ba10](https://github.com/usekaneo/kaneo/commit/767ba103aca3beeda0a6f0a0df4459ce071f3b74))
* :green_heart: fixing formatting in package.json ([4644f0f](https://github.com/usekaneo/kaneo/commit/4644f0f6e3413591c9dd837a67df7cf8e735718e))
* :sparkles: format drizzle.config.ts ([cccd3ae](https://github.com/usekaneo/kaneo/commit/cccd3aea9420d4815501ec0d15ef1dc08a1f1b15))
* adding cursor button ([3b33c69](https://github.com/usekaneo/kaneo/commit/3b33c69f43c6adb6ad2e11284d20fb294941016b))
* adding dynamic view height on sidebar ([e7f4360](https://github.com/usekaneo/kaneo/commit/e7f4360eaf74b57eb8de48c2709ac4bfd418ee60))
* adding loading state for projects, sync ws when creating new tasks ([3977931](https://github.com/usekaneo/kaneo/commit/3977931ae07de1bcbf3ed1652ffead18b4469b2f))
* changing release branch ([3636788](https://github.com/usekaneo/kaneo/commit/3636788ca23bf418ef098fa2dad4c0da67f09d74))
* fixed but when preloading a workspace / project ([19f3136](https://github.com/usekaneo/kaneo/commit/19f3136e1209203c7dded63c05ee7d6982e668f0))
* fixing build context ([fa736c5](https://github.com/usekaneo/kaneo/commit/fa736c5c60ac75b9a8d9a2f583c49b08d597d1cc))
* fixing empty states ([cdb92fe](https://github.com/usekaneo/kaneo/commit/cdb92fe80858c41f3fdf8009abff87c6df023773))
* fixing local development setup ([894d55d](https://github.com/usekaneo/kaneo/commit/894d55d1c6440b161dd66dd70c7b251db3be3069))
* fixing long task titles ([8927a97](https://github.com/usekaneo/kaneo/commit/8927a971e5b53cbc69bf543efd8bb1d7fd00778e))
* fixing route selection and creating tasks with no asignee ([ae9bc8e](https://github.com/usekaneo/kaneo/commit/ae9bc8eebecc4786e3e7630432e9bc98cf03dd0f))
* improving padding for user info section ([4e904bf](https://github.com/usekaneo/kaneo/commit/4e904bfc8051c49c3468690ae99fbce5706d7fcf))
* improving scrolling on dnd ([17a54fd](https://github.com/usekaneo/kaneo/commit/17a54fdfcbcb9bc43efbe7dd05dd854872930ad9))
* listing web's nginx conf ([9ae5b32](https://github.com/usekaneo/kaneo/commit/9ae5b3209d84529c7edc482f118826502327dfe9))
* major route refactor, adding empty / selection states ([4b448ec](https://github.com/usekaneo/kaneo/commit/4b448ec4f2e365553f62b345032abe713ae14bc3))
* making settings not dependant on a workspaceId ([4a15188](https://github.com/usekaneo/kaneo/commit/4a15188bbdefa3cb8012f42f308bcd5cfae23882))
* making sidebar fixed ([6761a4f](https://github.com/usekaneo/kaneo/commit/6761a4f9930d8f2c77241f2041c4b338750f7665))
* making sidebar on mobile floating ([c3ba0e2](https://github.com/usekaneo/kaneo/commit/c3ba0e244a0d86a7390d97b145e0330b795d8410))
* refactoring publishing flow ([5471b88](https://github.com/usekaneo/kaneo/commit/5471b88ee244064b69853fd0a914cf32803f9f8f))
* removing unused import ([9466dc5](https://github.com/usekaneo/kaneo/commit/9466dc5d18e46d8f30000cf110ed255b53a3045d))
* removing unused packages ([20a8c66](https://github.com/usekaneo/kaneo/commit/20a8c6694d1e1bc345655a4b85a56bf7a981dc48))
* removing unused packages ([49ba8d1](https://github.com/usekaneo/kaneo/commit/49ba8d196d44715dd736ad3de4690a70686f46a3))
* removing unused packages ([de87b29](https://github.com/usekaneo/kaneo/commit/de87b298d00cddf7fff0799bcce7149beb7f2123))
* reseting zustand after sign out ([9352b9f](https://github.com/usekaneo/kaneo/commit/9352b9f77b10fbd37c1ad5557e3368ad27c1fdb1))
* task title was overflowing when too long ([9627cb3](https://github.com/usekaneo/kaneo/commit/9627cb3c25b30e6fb5287a32aebb32bf76ddface))
* updated mutateFn for sign in / up flow ([73f6b68](https://github.com/usekaneo/kaneo/commit/73f6b681fdb084b541bc32738cb397f0b9f6717a))
* updated urls and removing urls ([fd7f1d7](https://github.com/usekaneo/kaneo/commit/fd7f1d765451fd55969fecb5331b61584698d296))
* updating docker context ([0bb17b5](https://github.com/usekaneo/kaneo/commit/0bb17b5d786c3ef110fbd16f08701b139bf39c7f))
* updating reamde ([d6d3ed8](https://github.com/usekaneo/kaneo/commit/d6d3ed8bf8cab3b9a27747c66c4d0ffdf9e2ba13))
* wrong z-index on modals ([2de17b8](https://github.com/usekaneo/kaneo/commit/2de17b8b1993d847a2f22a43891f2254b66ef3a2))


### Features

* :construction_worker: adding workflow to lint project ([382d6c5](https://github.com/usekaneo/kaneo/commit/382d6c5ef0a084d026a7238689f8a357fc05c5fa))
* :construction_worker: updating husky and commitlint ([33e2920](https://github.com/usekaneo/kaneo/commit/33e292027fea1d6dc4546a61b869f180e7d129e0))
* :construction_worker: updating workflow name ([f13d4ef](https://github.com/usekaneo/kaneo/commit/f13d4eff1c021be68b01c7381439d28629b6e22b))
* :fire: adding initial kanban board ([0e2734a](https://github.com/usekaneo/kaneo/commit/0e2734a4757722d753be398c9f7273b7fdfc1274))
* :fire: migrating to sessions, using file routes, adding auth provider ([d6f8ecc](https://github.com/usekaneo/kaneo/commit/d6f8ecce077e3fac67111e7585f81b6bd268d191))
* :sparkles: adding crud for workspaces ([faad3a4](https://github.com/usekaneo/kaneo/commit/faad3a49a327ed3cbee14d96a923997a5daf8bbd))
* :sparkles: adding marketing image ([841eee9](https://github.com/usekaneo/kaneo/commit/841eee9fcf4440370fdd95ee73731d591a6795b4))
* :sparkles: adding marketing image ([91ac6c1](https://github.com/usekaneo/kaneo/commit/91ac6c189ddc81535cf498abcfb8e63a8c32cead))
* :sparkles: adding marketing image ([e0dbd6b](https://github.com/usekaneo/kaneo/commit/e0dbd6bd41a440a0114e5c413d673601153d58a6))
* :sparkles: adding marketing image ([a8568c1](https://github.com/usekaneo/kaneo/commit/a8568c1f6d04685d387996448830b1fb166740e5))
* :sparkles: adding projects ([db2f600](https://github.com/usekaneo/kaneo/commit/db2f600d58ea45bf410f8b91de0577f969b2fbda))
* :sparkles: finishing authentication, adding color modes ([da9c10f](https://github.com/usekaneo/kaneo/commit/da9c10fa56ccf479977d3fad8a547d684067256d))
* :sparkles: finishing socket communication for tasks ([dcb8475](https://github.com/usekaneo/kaneo/commit/dcb84754b3bb970415bb7e16200224bef5271823))
* :sparkles: initial commit for projects ([200d9a6](https://github.com/usekaneo/kaneo/commit/200d9a6df400bab61bbc63f2a28dc3807da77606))
* :sparkles: updating logo design ([b8250e6](https://github.com/usekaneo/kaneo/commit/b8250e68fc3f8013b548750fb87140cb55811ac7))
* adding docker images and compose ([537b47e](https://github.com/usekaneo/kaneo/commit/537b47e328b8b5ee2ef1f0ffb71e78e8e3a42ee8))
* adding empty / error states ([5a0ae89](https://github.com/usekaneo/kaneo/commit/5a0ae89b2f43ee78f955840758bf95cb24fa8ec1))
* adding invites for users ([6f509ea](https://github.com/usekaneo/kaneo/commit/6f509ea85c76de40811282e673caa99ac174df69))
* adding multi platform build ([9e40708](https://github.com/usekaneo/kaneo/commit/9e407089a09f93c0a5ecc8296444f0d3f61f3400))
* adding pending invited users screen ([138dc70](https://github.com/usekaneo/kaneo/commit/138dc7084d9d30bc4a35e2ed94aed90e4c82dccc))
* adding project icons ([500783e](https://github.com/usekaneo/kaneo/commit/500783eb12a2fc64ff7e64d078638a4d4a16a0f2))
* adding project slugs ([e4cd25a](https://github.com/usekaneo/kaneo/commit/e4cd25a6b8c7bf6f6e3928b4dca6684270ed99a5))
* adding sensors for dnd ([3a9f2a9](https://github.com/usekaneo/kaneo/commit/3a9f2a91eaf7cc8c5f330c69cbf702aed0ab0def))
* adding settings page ([dd9ae8f](https://github.com/usekaneo/kaneo/commit/dd9ae8fd74008540c76caed0b7eed398ed408b54))
* changing cover image ([62cb2fb](https://github.com/usekaneo/kaneo/commit/62cb2fb88e9e42de923d68bdd889f87738757905))
* **create-turbo:** apply official-starter transform ([6fcda66](https://github.com/usekaneo/kaneo/commit/6fcda66be3d9e10f32705cd0a59d62eae0e8ef27))
* **create-turbo:** apply package-manager transform ([2aaf064](https://github.com/usekaneo/kaneo/commit/2aaf064f095549ad6600e89954aba9fc2c8385d9))
* **create-turbo:** create basic ([3b8654f](https://github.com/usekaneo/kaneo/commit/3b8654f88adfe575bdd6190af85ce8daeea7f810))
* finishing responsive-ness on manage teams screens ([bf5c55c](https://github.com/usekaneo/kaneo/commit/bf5c55c073f073e6be6fbcb0e3f5cb31a5b0c893))
* initial task edit setup ([2aacb26](https://github.com/usekaneo/kaneo/commit/2aacb262ab519eb1cc5e8c1a4aa3c1bcb9ba595c))
* making manage teams screens responsive ([e78f23c](https://github.com/usekaneo/kaneo/commit/e78f23ce379ceeb3e980095932b300e7ef409755))
* Teams refactor ([#70](https://github.com/usekaneo/kaneo/issues/70)) ([f8403cb](https://github.com/usekaneo/kaneo/commit/f8403cbf8630b9a3a534f6143f8f06896b354118))



# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).
